import { PresetSample } from '../types';

export const PRESET_SAMPLES: PresetSample[] = [
  {
    id: 'emergency-arterial',
    title: 'Arterial Bleed & Deep Trauma',
    scenario: 'EMERGENCY',
    badge: 'Code Red - Emergency',
    description: 'High-flow pulsatile forearm laceration with vascular compromise and hypovolemic signs.',
    imagePromptDescription: 'Pulsatile deep laceration on forearm with bright arterial extravasation',
    defaultSymptoms: 'Deep glass cut on right forearm 15 minutes ago, active spurting bright blood, feeling dizzy and cold.',
  },
  {
    id: 'emergency-stroke',
    title: 'Acute Facial Droop (Suspected CVA)',
    scenario: 'EMERGENCY',
    badge: 'Code Red - Emergency',
    description: 'Sudden onset unilateral facial asymmetry, slurred speech, left arm pronator drift.',
    imagePromptDescription: 'Facial asymmetry with unilateral ptosis and drooping of left mouth commissure',
    defaultSymptoms: 'Sudden drooping on the left side of face, difficulty forming coherent words, weakness in left arm.',
  },
  {
    id: 'routine-dermatitis',
    title: 'Contact Dermatitis Rash',
    scenario: 'NORMAL_ROUTINE',
    badge: 'Routine Diagnosis',
    description: 'Subacute erythematous maculopapular rash on skin with mild superficial scaling.',
    imagePromptDescription: 'Circumscribed erythematous rash with small papules on dorsal forearm',
    defaultSymptoms: 'Itchy reddish bumpy rash developed after gardening 2 days ago, no fever or shortness of breath.',
  },
  {
    id: 'routine-conjunctivitis',
    title: 'Allergic / Viral Conjunctivitis',
    scenario: 'NORMAL_ROUTINE',
    badge: 'Routine Diagnosis',
    description: 'Unilateral conjunctival injection with watery discharge and photophobia.',
    imagePromptDescription: 'Scleral hypervascularity with clear discharge and intact cornea',
    defaultSymptoms: 'Red eye with mild gritty burning sensation since yesterday morning, clear watery discharge.',
  },
  {
    id: 'routine-ankle-sprain',
    title: 'Mild Ankle Ligamentous Strain',
    scenario: 'NORMAL_ROUTINE',
    badge: 'Routine Diagnosis',
    description: 'Localized swelling and mild ecchymosis over anterior talofibular ligament.',
    imagePromptDescription: 'Mild edema and localized swelling over lateral malleolus of ankle',
    defaultSymptoms: 'Twisted ankle walking down stairs 4 hours ago, able to bear slight weight, tender on outside of ankle.',
  },
];
