export type ScanScenario = 'NORMAL_ROUTINE' | 'EMERGENCY';

export type EmergencySeverityLevel =
  | 'CRITICAL_LIFE_THREATENING'
  | 'URGENT'
  | 'NON_URGENT'
  | 'ROUTINE';

export interface SpecialistRecommendation {
  specialty: string;
  reason: string;
  urgencyTimeframe: string;
  preparationNotes: string;
}

export interface HospitalER {
  name: string;
  address: string;
  distanceKm: number;
  estimatedDriveTimeMin: number;
  emergencyPhone: string;
  hasLevel1TraumaCenter: boolean;
  googleMapsUrl: string;
  lat?: number;
  lng?: number;
  isSubscribedPartner?: boolean;
}

export interface RoutineClinic {
  name: string;
  type: string;
  address: string;
  distanceKm: number;
  phone: string;
  rating: number;
  specialtiesOffered: string[];
  googleMapsUrl: string;
  bookingNote?: string;
}

export interface SurgicalMedicalReport {
  reportId: string;
  timestamp: string;
  patientAcuityCode: 'CODE_RED_STAT' | 'CODE_ORANGE_URGENT' | 'CODE_YELLOW_STABLE';
  triageCategory: string;
  chiefComplaint: string;
  clinicalObservations: string[];
  vitalSignsRiskAssessment: {
    airwayBreathingCirculation: string;
    consciousnessLevel: string;
    shockRisk: string;
    estimatedBloodLoss?: string;
  };
  suspectedPathology: string;
  preHospitalOrders: string[];
  immediateInterventionsNeeded: string[];
  anesthesiaSurgicalPrecautions: string[];
  attendingSpecialty: string;
  facilityDestination: string;
}

export interface ScanAnalysisResult {
  scenario: ScanScenario;
  severityLevel: EmergencySeverityLevel;
  severityScore: number; // 1 to 10 scale
  primaryDiagnosis: string;
  confidencePercentage: number;
  differentialDiagnoses: string[];
  conditionSummary: string;
  visualFindings: string[];
  vitalSignsRiskAssessment: {
    airwayBreathingCirculation: string;
    consciousnessLevel: string;
    shockRisk: string;
    estimatedBloodLoss?: string;
  };
  specialist: SpecialistRecommendation;
  nearestHospitalER?: HospitalER;
  routineClinics?: RoutineClinic[];
  firstAidAndImmediateActions: string[];
  surgicalMedicalReport?: SurgicalMedicalReport;
  disclaimer: string;
}

export interface UserLocation {
  latitude: number;
  longitude: number;
  city?: string;
  region?: string;
  country?: string;
  accuracy?: number;
}

export interface PresetSample {
  id: string;
  title: string;
  scenario: ScanScenario;
  badge: string;
  description: string;
  imagePromptDescription: string;
  defaultSymptoms: string;
}

// ----------------------------------------------------------------------
// HOSPITAL PREMIUM SUBSCRIPTION SYSTEM ($104 India / $1,000 Global)
// ----------------------------------------------------------------------

export type SubscriptionCountry = 'IN' | 'GLOBAL';

export interface HospitalSubscriptionTier {
  id: string;
  region: SubscriptionCountry;
  name: string;
  monthlyPriceUSD: number;
  monthlyPriceLocalDisplay: string;
  billingFrequency: 'Monthly';
  headline: string;
  features: string[];
  cloudBigtableIngressIncluded: string;
  cloudSpannerNodes: number;
  bigqueryGeoAnalyticsQueries: string;
  colossusStorageQuotaGB: number;
  cloudNatDedicatedGateway: boolean;
}

export interface SubscribedHospital {
  id: string;
  hospitalName: string;
  licenseNumber: string;
  country: SubscriptionCountry;
  countryName: string;
  city: string;
  address: string;
  lat: number;
  lng: number;
  contactEmail: string;
  phone: string;
  traumaLevel: 'Level 1 Trauma Center' | 'Level 2 Regional ER' | 'Specialty Surgical Center';
  bedCapacity: number;
  activeStatus: 'ACTIVE' | 'PENDING_VERIFICATION' | 'RENEWAL_DUE';
  subscriptionMonthlyRateUSD: number;
  subscriptionPlanName: string;
  subscribedSince: string;
  nextRenewalDate: string;
  bigtableInstanceId: string;
  spannerTenantId: string;
  colossusBucketPrefix: string;
  stats: {
    monthlyVideoScansReceived: number;
    avgERResponseMinutes: number;
    emergencyCasesDispatched: number;
    patientAcuityAccuracy: string;
  };
}

// ----------------------------------------------------------------------
// CLOUD ARCHITECTURE & OPEN SOURCE CLOUD DATA TYPES
// ----------------------------------------------------------------------

export interface BigtableTelemetryRow {
  rowKey: string; // [HOSPITAL_ID]#[PATIENT_ID]#[REVERSE_TIMESTAMP]
  timestamp: string;
  columnFamily: 'sensor_telemetry' | 'optical_features' | 'triage_metrics';
  qualifier: string;
  value: string | number;
}

export interface BigtableInstanceStatus {
  instanceId: string;
  displayName: string;
  clusterLocation: string;
  nodeCount: number;
  storageType: 'SSD';
  currentReadQPS: number;
  currentWriteQPS: number;
  p99LatencyMs: number;
  sampleRows: BigtableTelemetryRow[];
}

export interface SpannerTransactionRecord {
  txId: string;
  timestamp: string;
  hospitalId: string;
  operation: 'INSERT_SUBSCRIPTION' | 'CHARGE_MONTHLY_FEE' | 'MUTATE_BED_STATUS' | 'ACID_TRIAGE_DISPATCH';
  amountUSD?: number;
  status: 'COMMITTED' | 'ROLLBACK';
  readTimestampMs: number;
}

export interface SpannerInstanceStatus {
  instanceId: string;
  config: 'regional-us-central1' | 'regional-asia-south1-mumbai' | 'multi-region-eur3';
  nodeCount: number;
  processingUnits: number;
  database: string;
  dialect: 'GOOGLE_STANDARD_SQL';
  sampleTransactions: SpannerTransactionRecord[];
}

export interface BigQueryGeoRecord {
  hospital_id: string;
  hospital_name: string;
  country: string;
  monthly_fee_usd: number;
  location_geography: string; // ST_GEOGPOINT(lng, lat)
  trauma_level: string;
  distance_meters: number;
}

export interface BigQueryFederationStatus {
  datasetId: string;
  geographyColumnName: string;
  spannerFederationConnectionUri: string;
  sampleGeoQuery: string;
  federatedResults: BigQueryGeoRecord[];
}

export interface ColossusGcsFile {
  id: string;
  objectName: string;
  bucketName: string;
  contentType: string;
  sizeBytes: number;
  storageClass: 'STANDARD' | 'COLDLINE';
  internalSubsystem: 'Colossus Distributed Chunk Storage';
  uploadedAt: string;
  downloadUrl: string;
}

export interface VpcCloudNatStatus {
  vpcNetwork: string;
  subnetName: string;
  ipCidrRange: string;
  routerName: string;
  natGatewayName: string;
  allocatedNatIps: string[];
  minPortsPerVm: number;
  enableEndpointIndependentMapping: boolean;
  securityState: 'PRIVATE_ONLY_ZERO_INGRESS_ENABLED';
  recentOutboundEgressTraffic: {
    destination: string;
    port: number;
    protocol: string;
    bytesSent: number;
    status: 'NAT_TRANSLATED_OK';
    timestamp: string;
  }[];
}

export interface OpenSourceDatasetItem {
  id: string;
  name: string;
  category: 'Geospatial Emergency Facilities' | 'Clinical Triage Data' | 'Vital Signs Telemetry';
  recordsCount: string;
  license: string;
  format: string;
  description: string;
  schemaSample: Record<string, string>;
  downloadEndpoint: string;
}

export interface CodeGenRequest {
  targetComponent: 'bigtable' | 'spanner' | 'bigquery_geo' | 'colossus_gcs' | 'cloud_nat' | 'terraform_all';
  language: 'typescript' | 'sql' | 'terraform' | 'python' | 'bash';
  customInstructions?: string;
}

export interface CodeGenResponse {
  code: string;
  explanation: string;
  modelUsed: string;
  component: string;
  language: string;
}
