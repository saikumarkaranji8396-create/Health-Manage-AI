import React, { useState } from 'react';
import {
  X,
  Printer,
  Download,
  Copy,
  Check,
  Hospital,
  AlertTriangle,
  Activity,
  FileCheck,
  ShieldAlert,
  HardDrive,
  Database,
} from 'lucide-react';
import { SurgicalMedicalReport, HospitalER } from '../types';

interface MedicalReportModalProps {
  report: SurgicalMedicalReport;
  hospital?: HospitalER;
  onClose: () => void;
  onDownloadPDF: () => void;
}

export const MedicalReportModal: React.FC<MedicalReportModalProps> = ({
  report,
  hospital,
  onClose,
  onDownloadPDF,
}) => {
  const [copied, setCopied] = useState<boolean>(false);

  const handleCopySummary = () => {
    const summaryText = `EMERGENCY SURGICAL & MEDICAL REPORT [${report.reportId}]
Acuity: ${report.patientAcuityCode} (${report.triageCategory})
Timestamp: ${new Date(report.timestamp).toLocaleString()}
Destination ER: ${hospital?.name || report.facilityDestination}
CHIEF COMPLAINT: ${report.chiefComplaint}
SUSPECTED PATHOLOGY: ${report.suspectedPathology}
OPTICAL FINDINGS:
${report.clinicalObservations.map((o) => `• ${o}`).join('\n')}
VITALS / ABC STATUS:
- ABC: ${report.vitalSignsRiskAssessment.airwayBreathingCirculation}
- Consciousness: ${report.vitalSignsRiskAssessment.consciousnessLevel}
- Shock Risk: ${report.vitalSignsRiskAssessment.shockRisk}
IMMEDIATE SURGICAL INTERVENTIONS NEEDED:
${report.immediateInterventionsNeeded.map((i) => `[!] ${i}`).join('\n')}
PRE-HOSPITAL ORDERS:
${report.preHospitalOrders.map((o) => `• ${o}`).join('\n')}`;

    navigator.clipboard.writeText(summaryText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-slate-900 border-2 border-rose-500/80 rounded-2xl shadow-2xl overflow-hidden my-auto">
        {/* Modal Header Bar */}
        <div className="bg-rose-950/90 border-b border-rose-800 px-5 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <ShieldAlert className="w-5 h-5 text-rose-400" />
            <div>
              <h3 className="text-sm sm:text-base font-black text-white tracking-wide">
                DIGITAL SCAN SURGICAL &amp; MEDICAL REPORT
              </h3>
              <p className="text-[11px] text-rose-300 font-mono">
                SYNTHESIZED FOR ATTENDING SURGEONS &amp; ER PHYSICIANS
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopySummary}
              title="Copy Summary Text"
              className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs flex items-center gap-1 transition-colors"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
            <button
              onClick={onDownloadPDF}
              title="Download PDF"
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-colors shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              <span>PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable/Readable Medical Document Body */}
        <div className="p-5 sm:p-6 space-y-5 max-h-[80vh] overflow-y-auto text-slate-200">
          {/* Metadata Card */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono">
            <div>
              <span className="text-slate-500 block text-[10px]">REPORT ID</span>
              <span className="text-cyan-300 font-bold">{report.reportId}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">PATIENT ACUITY</span>
              <span className="text-rose-400 font-black">{report.patientAcuityCode}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">TIMESTAMP</span>
              <span className="text-slate-300">
                {new Date(report.timestamp).toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                  second: '2-digit',
                })}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">RECEIVING ER</span>
              <span className="text-slate-200 font-medium truncate block">
                {hospital?.name || report.facilityDestination}
              </span>
            </div>
          </div>

          {/* Section 1: Chief Complaint & Pathology */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-rose-400 uppercase tracking-wider flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5" />
              1. Chief Complaint &amp; Suspected Surgical Pathology
            </h4>
            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1.5 text-xs">
              <p>
                <strong className="text-slate-300">Complaint:</strong>{' '}
                <span className="text-slate-100 font-semibold">{report.chiefComplaint}</span>
              </p>
              <p>
                <strong className="text-slate-300">Suspected Pathology:</strong>{' '}
                <span className="text-slate-200">{report.suspectedPathology}</span>
              </p>
            </div>
          </div>

          {/* Section 2: Clinical Observations */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5" />
              2. Real-Time Optical Findings (Gemini 2.5 Pro Vision)
            </h4>
            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 text-xs">
              <ul className="space-y-1.5">
                {report.clinicalObservations.map((obs, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-cyan-400 font-bold">•</span>
                    <span>{obs}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Section 3: Vitals & ABC Risk */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider">
              3. Vitals &amp; Airway-Breathing-Circulation (ABC) Risk Assessment
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">AIRWAY &amp; BREATHING</span>
                <span className="text-slate-200 font-medium">
                  {report.vitalSignsRiskAssessment.airwayBreathingCirculation}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">CONSCIOUSNESS</span>
                <span className="text-slate-200 font-medium">
                  {report.vitalSignsRiskAssessment.consciousnessLevel}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">SHOCK SEVERITY</span>
                <span className="text-rose-400 font-bold">
                  {report.vitalSignsRiskAssessment.shockRisk}
                </span>
              </div>
            </div>
          </div>

          {/* Section 4: Immediate Surgical Orders */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-rose-400 uppercase tracking-wider flex items-center gap-1.5">
              <FileCheck className="w-3.5 h-3.5" />
              4. Immediate Surgical &amp; Resuscitation Orders (STAT)
            </h4>
            <div className="p-4 rounded-xl bg-rose-950/30 border border-rose-900/60 text-xs space-y-2">
              {report.immediateInterventionsNeeded.map((intv, idx) => (
                <div key={idx} className="flex items-start gap-2 text-rose-200 font-medium">
                  <span className="px-1.5 py-0.2 bg-rose-900 text-rose-100 rounded text-[10px] font-mono">
                    STAT
                  </span>
                  <span>{intv}</span>
                </div>
              ))}
              {report.anesthesiaSurgicalPrecautions && report.anesthesiaSurgicalPrecautions.length > 0 && (
                <div className="pt-2 border-t border-rose-900/40 text-amber-300 text-[11px] italic">
                  Anesthesia Note: {report.anesthesiaSurgicalPrecautions[0]}
                </div>
              )}
            </div>
          </div>

          {/* Section 5: Pre-Hospital Orders */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              5. Pre-Hospital Paramedic Protocol
            </h4>
            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 text-xs space-y-1.5">
              {report.preHospitalOrders.map((order, idx) => (
                <div key={idx} className="flex items-start gap-2 text-slate-300">
                  <span className="text-cyan-400">•</span>
                  <span>{order}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-950 px-5 py-3.5 border-t border-slate-800 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-slate-500 text-[11px]">
            <HardDrive className="w-3.5 h-3.5 text-purple-400" />
            <span>Colossus GCS Vault Synced • Cloud Spanner ACID Recorded</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            >
              Close
            </button>
            <button
              onClick={onDownloadPDF}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold transition-colors shadow-md"
            >
              <Download className="w-4 h-4" />
              <span>Download PDF</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
