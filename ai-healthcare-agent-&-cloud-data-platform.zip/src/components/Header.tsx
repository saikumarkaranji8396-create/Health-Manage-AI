import React from 'react';
import {
  Activity,
  MapPin,
  PhoneCall,
  Building2,
  Cloud,
  FileCode,
  ShieldCheck,
} from 'lucide-react';
import { UserLocation } from '../types';

export type AppActiveTab = 'scanner' | 'subscriptions' | 'cloud_architecture' | 'open_source_studio';

interface HeaderProps {
  location: UserLocation | null;
  locationLoading: boolean;
  onRequestLocation: () => void;
  isCameraActive: boolean;
  activeTab: AppActiveTab;
  onTabChange: (tab: AppActiveTab) => void;
  subscribedHospitalCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  location,
  locationLoading,
  onRequestLocation,
  isCameraActive,
  activeTab,
  onTabChange,
  subscribedHospitalCount,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 text-white shadow-md">
      {/* Top brand & status bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-3">
        {/* Brand & App Name */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 via-teal-500 to-emerald-500 flex items-center justify-center text-white shadow-md shadow-cyan-900/30">
            <Activity className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-black tracking-tight text-white flex items-center gap-1.5">
                AI Healthcare Agent
              </h1>
              <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-cyan-950 text-cyan-300 border border-cyan-800">
                Cloud Data Engine
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              Gemini 2.5 Pro Vision Triage • Bigtable • Spanner • BigQuery Geo • GCS Colossus • Cloud NAT
            </p>
          </div>
        </div>

        {/* Action Controls & Emergency Pill */}
        <div className="flex items-center gap-2 sm:gap-3 ml-auto">
          {/* Camera status badge */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-slate-800 border border-slate-700 text-slate-300">
            <span
              className={`w-2 h-2 rounded-full ${
                isCameraActive ? 'bg-emerald-400 animate-ping' : 'bg-slate-500'
              }`}
            />
            <span className="hidden md:inline">Camera:</span>
            <span>{isCameraActive ? 'Live' : 'Standby'}</span>
          </div>

          {/* Location button */}
          <button
            onClick={onRequestLocation}
            title="Update Current GPS Location"
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 transition-colors"
          >
            <MapPin className={`w-3.5 h-3.5 text-cyan-400 ${locationLoading ? 'animate-spin' : ''}`} />
            <span className="max-w-[110px] sm:max-w-[150px] truncate">
              {locationLoading
                ? 'Locating...'
                : location?.city || (location ? `${location.latitude.toFixed(2)}, ${location.longitude.toFixed(2)}` : 'Set Location')}
            </span>
          </button>

          {/* Emergency SOS Call */}
          <a
            href="tel:911"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white shadow-sm shadow-rose-900/40 transition-all transform hover:scale-[1.02] active:scale-[0.98]"
          >
            <PhoneCall className="w-3.5 h-3.5 animate-bounce" />
            <span>SOS 911</span>
          </a>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 border-t border-slate-800/80 flex items-center overflow-x-auto no-scrollbar gap-1 py-1.5">
        <button
          onClick={() => onTabChange('scanner')}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${
            activeTab === 'scanner'
              ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
          }`}
        >
          <Activity className="w-3.5 h-3.5 text-cyan-400" />
          <span>Body Scanner &amp; Triage</span>
        </button>

        <button
          onClick={() => onTabChange('subscriptions')}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${
            activeTab === 'subscriptions'
              ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
          }`}
        >
          <Building2 className="w-3.5 h-3.5 text-emerald-400" />
          <span>Hospital Subscriptions</span>
          <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-800">
            $104 India / $1k Global
          </span>
        </button>

        <button
          onClick={() => onTabChange('cloud_architecture')}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${
            activeTab === 'cloud_architecture'
              ? 'bg-blue-500/15 text-blue-300 border border-blue-500/30'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
          }`}
        >
          <Cloud className="w-3.5 h-3.5 text-blue-400" />
          <span>Cloud Data Architecture</span>
          <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-slate-800 text-slate-300">
            Bigtable • Spanner • Geo • NAT
          </span>
        </button>

        <button
          onClick={() => onTabChange('open_source_studio')}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${
            activeTab === 'open_source_studio'
              ? 'bg-purple-500/15 text-purple-300 border border-purple-500/30'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
          }`}
        >
          <FileCode className="w-3.5 h-3.5 text-purple-400" />
          <span>Open Source &amp; Gemini 2.5 Pro Code</span>
        </button>
      </div>
    </header>
  );
};
