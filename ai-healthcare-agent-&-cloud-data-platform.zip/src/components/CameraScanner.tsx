import React, { useRef, useState, useEffect, useCallback } from 'react';
import {
  Camera,
  RotateCw,
  Zap,
  Crosshair,
  AlertTriangle,
  Upload,
  Sparkles,
  RefreshCw,
  Layers,
  HeartPulse,
  Database,
  Building2,
} from 'lucide-react';
import { PRESET_SAMPLES } from '../data/presets';
import { PresetSample } from '../types';

interface CameraScannerProps {
  onCaptureScan: (imageDataBase64: string, notes: string, scenarioHint?: string) => void;
  isAnalyzing: boolean;
  onCameraStateChange?: (isActive: boolean) => void;
  onNavigateToSubscriptions?: () => void;
}

export const CameraScanner: React.FC<CameraScannerProps> = ({
  onCaptureScan,
  isAnalyzing,
  onCameraStateChange,
  onNavigateToSubscriptions,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('environment');
  const [streamActive, setStreamActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [selectedPreset, setSelectedPreset] = useState<PresetSample | null>(null);
  const [customImage, setCustomImage] = useState<string | null>(null);
  const [symptomNotes, setSymptomNotes] = useState<string>('');
  const [isScanningAnimation, setIsScanningAnimation] = useState<boolean>(true);
  const [simulatedVitals, setSimulatedVitals] = useState({ hr: 82, spo2: 98, qps: 14200 });

  // Vitals simulation + Bigtable QPS rate
  useEffect(() => {
    const interval = setInterval(() => {
      setSimulatedVitals((prev) => ({
        hr: Math.min(125, Math.max(68, prev.hr + (Math.random() > 0.5 ? 1 : -1))),
        spo2: Math.min(100, Math.max(95, prev.spo2 + (Math.random() > 0.7 ? -1 : 1))),
        qps: Math.min(16000, Math.max(12000, prev.qps + Math.floor((Math.random() - 0.5) * 500))),
      }));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  // Initialize camera
  const startCamera = useCallback(async () => {
    setCameraError(null);
    try {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach((track) => track.stop());
      }
      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: { ideal: facingMode },
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      };
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        setStreamActive(true);
        onCameraStateChange?.(true);
      }
    } catch (err: any) {
      console.warn('Camera access error:', err);
      setCameraError(
        'Live camera stream unavailable or permission denied in this browser frame. You can use preset clinical scans or upload a photo below.'
      );
      setStreamActive(false);
      onCameraStateChange?.(false);
    }
  }, [facingMode, onCameraStateChange]);

  const toggleFacingMode = () => {
    setFacingMode((prev) => (prev === 'user' ? 'environment' : 'user'));
  };

  useEffect(() => {
    startCamera();
    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach((track) => track.stop());
      }
      onCameraStateChange?.(false);
    };
  }, [facingMode, startCamera, onCameraStateChange]);

  const captureCurrentFrame = (): string | null => {
    if (customImage) return customImage;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas || video.videoWidth === 0) return null;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.85);
  };

  const handleTriggerScan = () => {
    const frame = captureCurrentFrame();
    if (selectedPreset) {
      onCaptureScan(frame || '', symptomNotes || selectedPreset.defaultSymptoms, selectedPreset.scenario);
    } else {
      onCaptureScan(frame || '', symptomNotes || 'Physical body area scan evaluation', undefined);
    }
  };

  const handleSelectPreset = (preset: PresetSample) => {
    setSelectedPreset(preset);
    setSymptomNotes(preset.defaultSymptoms);
    setCustomImage(null);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        setCustomImage(result);
        setSelectedPreset(null);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-800 p-4 sm:p-5 shadow-xl overflow-hidden space-y-4">
      {/* Video Viewport with Medical HUD */}
      <div className="relative w-full aspect-[4/3] sm:aspect-[16/9] bg-black rounded-xl overflow-hidden border border-slate-700/80 shadow-inner flex items-center justify-center">
        <canvas ref={canvasRef} className="hidden" />

        {/* Custom Uploaded Image / Preset preview */}
        {customImage ? (
          <div className="relative w-full h-full">
            <img
              src={customImage}
              alt="Scan source"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <button
              onClick={() => setCustomImage(null)}
              className="absolute top-3 right-3 px-2 py-1 text-xs bg-black/70 hover:bg-black/90 text-white rounded border border-white/20 backdrop-blur-sm z-30"
            >
              Reset to Camera
            </button>
          </div>
        ) : (
          <video
            ref={videoRef}
            playsInline
            muted
            autoPlay
            className={`w-full h-full object-cover ${
              facingMode === 'user' ? 'scale-x-[-1]' : ''
            }`}
          />
        )}

        {/* Camera stream fallback prompt */}
        {!streamActive && !customImage && (
          <div className="absolute inset-0 bg-slate-950/90 flex flex-col items-center justify-center p-6 text-center z-10">
            <div className="w-14 h-14 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-cyan-400 mb-3 shadow-lg">
              <Camera className="w-7 h-7" />
            </div>
            <h3 className="text-sm font-semibold text-slate-200 mb-1">
              Live Camera Stream Ready
            </h3>
            <p className="text-xs text-slate-400 max-w-sm mb-4">
              {cameraError ||
                'Allow camera permission to scan human body in real time, or test immediately using clinical presets below.'}
            </p>
            <div className="flex flex-wrap gap-2 justify-center">
              <button
                onClick={startCamera}
                className="px-3 py-1.5 rounded-lg text-xs font-medium bg-cyan-600 hover:bg-cyan-500 text-white transition-colors flex items-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Retry Camera
              </button>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center gap-1.5"
              >
                <Upload className="w-3.5 h-3.5" />
                Upload Photo/Scan
              </button>
            </div>
          </div>
        )}

        {/* Futuristic Medical HUD Overlay */}
        <div className="absolute inset-0 pointer-events-none p-3 sm:p-4 flex flex-col justify-between z-20">
          {/* Top HUD bar */}
          <div className="flex items-center justify-between text-xs text-cyan-400/90 font-mono tracking-wider">
            <div className="flex items-center gap-2 bg-slate-950/80 backdrop-blur-md px-2.5 py-1 rounded-md border border-cyan-500/30">
              <div className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              <span>LIVE AI STREAM</span>
              <span className="text-slate-400">|</span>
              <span className="text-slate-300">GEMINI 2.5 PRO VISION</span>
            </div>
            <div className="flex items-center gap-3 bg-slate-950/80 backdrop-blur-md px-2.5 py-1 rounded-md border border-cyan-500/30">
              <div className="flex items-center gap-1 text-rose-400">
                <HeartPulse className="w-3.5 h-3.5 animate-pulse" />
                <span>{simulatedVitals.hr} BPM</span>
              </div>
              <span className="text-emerald-400">SpO₂ {simulatedVitals.spo2}%</span>
              <span className="text-cyan-300 hidden sm:inline">Bigtable {simulatedVitals.qps} QPS</span>
            </div>
          </div>

          {/* Center Target Reticle & Crosshairs */}
          <div className="relative flex items-center justify-center my-auto">
            <div className="relative w-48 h-48 sm:w-64 sm:h-64 border border-cyan-500/40 rounded-2xl flex items-center justify-center">
              <div className="absolute -top-1 -left-1 w-6 h-6 border-t-2 border-l-2 border-cyan-400" />
              <div className="absolute -top-1 -right-1 w-6 h-6 border-t-2 border-r-2 border-cyan-400" />
              <div className="absolute -bottom-1 -left-1 w-6 h-6 border-b-2 border-l-2 border-cyan-400" />
              <div className="absolute -bottom-1 -right-1 w-6 h-6 border-b-2 border-r-2 border-cyan-400" />
              <Crosshair className="w-8 h-8 text-cyan-400/60 animate-spin-slow" />
              {isScanningAnimation && (
                <div className="absolute inset-x-0 h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_12px_#22d3ee] animate-scan" />
              )}
              <div className="absolute -bottom-7 px-2 py-0.5 rounded text-[10px] bg-cyan-950/80 text-cyan-300 border border-cyan-700/50 backdrop-blur-sm whitespace-nowrap">
                ALIGN BODY AREA / WOUND HERE
              </div>
            </div>
          </div>

          {/* Bottom HUD bar */}
          <div className="flex items-center justify-between text-[11px] text-slate-300 font-mono">
            <div className="bg-slate-950/80 backdrop-blur-md px-2 py-1 rounded border border-slate-700/50">
              TARGET: {selectedPreset ? selectedPreset.title : 'LIVE CAMERA'}
            </div>
            <div className="bg-slate-950/80 backdrop-blur-md px-2 py-1 rounded border border-slate-700/50 text-cyan-300">
              {selectedPreset?.scenario === 'EMERGENCY'
                ? 'CRITICAL EMERGENCY PROTOCOL (ER ROUTE)'
                : 'CLINICAL TRIAGE ACTIVE'}
            </div>
          </div>
        </div>

        {/* Camera Control Overlays */}
        <div className="absolute top-3 right-3 flex items-center gap-1.5 z-30">
          <button
            onClick={toggleFacingMode}
            title="Flip camera (Front / Back)"
            className="p-2 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-white border border-slate-700 shadow-md backdrop-blur-sm transition-transform active:scale-90"
          >
            <RotateCw className="w-4 h-4 text-cyan-300" />
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFileUpload}
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            title="Upload Photo of Body / Wound"
            className="p-2 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-white border border-slate-700 shadow-md backdrop-blur-sm transition-transform active:scale-90"
          >
            <Upload className="w-4 h-4 text-slate-200" />
          </button>
        </div>
      </div>

      {/* Quick Test Clinical Presets */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            <span>Select Clinical Case to Scan:</span>
          </label>
          <span className="text-[11px] text-slate-400">
            Emergency vs Routine Triage
          </span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {PRESET_SAMPLES.map((preset) => {
            const isSelected = selectedPreset?.id === preset.id;
            const isEmergency = preset.scenario === 'EMERGENCY';
            return (
              <button
                key={preset.id}
                onClick={() => handleSelectPreset(preset)}
                className={`text-left p-2.5 rounded-xl border transition-all ${
                  isSelected
                    ? isEmergency
                      ? 'bg-rose-950/60 border-rose-500 shadow-md shadow-rose-950/50 ring-1 ring-rose-500'
                      : 'bg-cyan-950/60 border-cyan-500 shadow-md shadow-cyan-950/50 ring-1 ring-cyan-500'
                    : 'bg-slate-800/60 hover:bg-slate-800 border-slate-700/80'
                }`}
              >
                <div className="flex items-center justify-between gap-1.5 mb-1">
                  <span
                    className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                      isEmergency
                        ? 'bg-rose-900/80 text-rose-200 border border-rose-700'
                        : 'bg-emerald-900/80 text-emerald-200 border border-emerald-700'
                    }`}
                  >
                    {isEmergency ? 'Scenario 2: Emergency' : 'Scenario 1: Routine'}
                  </span>
                  {isSelected && (
                    <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                  )}
                </div>
                <h4 className="text-xs font-bold text-slate-100 truncate">
                  {preset.title}
                </h4>
                <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                  {preset.description}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Patient Symptoms Field */}
      <div>
        <label className="text-xs font-medium text-slate-300 block mb-1">
          Reported Symptoms / Body Sensations (Optional):
        </label>
        <input
          type="text"
          value={symptomNotes}
          onChange={(e) => setSymptomNotes(e.target.value)}
          placeholder="e.g., Severe pulsating bleeding on arm; sudden left-sided facial weakness; itchy red rash..."
          className="w-full bg-slate-800/80 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors"
        />
      </div>

      {/* Main Scan Trigger Button */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <button
          disabled={isAnalyzing}
          onClick={handleTriggerScan}
          className={`w-full py-3.5 px-6 rounded-xl font-bold text-sm text-white shadow-lg transition-all flex items-center justify-center gap-2 transform active:scale-[0.99] ${
            selectedPreset?.scenario === 'EMERGENCY'
              ? 'bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 shadow-rose-900/40 ring-1 ring-rose-400'
              : 'bg-gradient-to-r from-cyan-600 via-teal-600 to-emerald-600 hover:from-cyan-500 hover:to-teal-500 shadow-cyan-900/40 ring-1 ring-cyan-400'
          } ${isAnalyzing ? 'opacity-80 cursor-wait' : ''}`}
        >
          {isAnalyzing ? (
            <>
              <RefreshCw className="w-5 h-5 animate-spin" />
              <span>Analyzing Video Stream via Gemini 2.5 Pro Vision...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5 animate-bounce" />
              <span>
                {selectedPreset
                  ? `Scan & Triage: ${selectedPreset.title}`
                  : 'Scan Body via Live Video Stream'}
              </span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
