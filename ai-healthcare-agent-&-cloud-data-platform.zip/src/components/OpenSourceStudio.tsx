import React, { useState, useEffect } from 'react';
import {
  FileCode,
  Sparkles,
  Download,
  Copy,
  Check,
  Play,
  Database,
  Globe,
  HardDrive,
  ShieldCheck,
  Server,
  Layers,
  Terminal,
  RefreshCw,
  ExternalLink,
  Code2,
} from 'lucide-react';
import { OpenSourceDatasetItem } from '../types';

export const OpenSourceStudio: React.FC = () => {
  const [datasets, setDatasets] = useState<OpenSourceDatasetItem[]>([]);
  const [loadingDatasets, setLoadingDatasets] = useState(false);

  // Gemini 2.5 Pro Code Generator state
  const [selectedComponent, setSelectedComponent] = useState<
    'bigtable' | 'spanner' | 'bigquery_geo' | 'colossus_gcs' | 'cloud_nat' | 'terraform_all'
  >('bigtable');
  const [selectedLanguage, setSelectedLanguage] = useState<'terraform' | 'typescript' | 'sql' | 'python'>('typescript');
  const [customPrompt, setCustomPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedCode, setGeneratedCode] = useState<string>('');
  const [modelLabel, setModelLabel] = useState<string>('gemini-2.5-pro');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetchDatasets();
    // Pre-generate initial code
    handleGenerateCode('bigtable', 'typescript');
  }, []);

  const fetchDatasets = async () => {
    try {
      setLoadingDatasets(true);
      const res = await fetch('/api/cloud-data/open-source-datasets');
      const data = await res.json();
      if (data.success) setDatasets(data.datasets);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingDatasets(false);
    }
  };

  const handleGenerateCode = async (
    target = selectedComponent,
    lang = selectedLanguage,
    instructions = customPrompt
  ) => {
    setIsGenerating(true);
    try {
      const res = await fetch('/api/gemini/generate-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetComponent: target,
          language: lang,
          customInstructions: instructions,
        }),
      });
      const data = await res.json();
      if (data.success && data.code) {
        setGeneratedCode(data.code);
        setModelLabel(data.modelUsed || 'gemini-2.5-pro');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(generatedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8">
      {/* Hero Header */}
      <div className="bg-gradient-to-br from-slate-900 via-purple-950/40 to-slate-900 border border-purple-500/30 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1.5 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-purple-950 text-purple-300 border border-purple-800">
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              <span>Open Source Cloud Data &amp; Gemini 2.5 Pro Code Generator</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              Open Source Cloud Data &amp; AI Architecture Studio
            </h2>
            <p className="text-xs sm:text-sm text-slate-300">
              Harness open healthcare cloud datasets alongside Gemini 2.5 Pro code generation for Cloud Bigtable, Cloud Spanner, BigQuery Geospatial, Colossus GCS, and VPC Cloud NAT.
            </p>
          </div>
        </div>
      </div>

      {/* Part 1: Interactive Gemini 2.5 Pro Code Generator */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 space-y-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Code2 className="w-5 h-5 text-purple-400" />
              <span>Gemini 2.5 Pro Code Generation Studio</span>
            </h3>
            <p className="text-xs text-slate-400">
              Generate production-grade GCP SDK code, SQL DDL, and Terraform modules powered by Gemini 2.5 Pro
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-lg text-xs font-mono font-bold bg-purple-950 text-purple-300 border border-purple-800">
              Model: {modelLabel}
            </span>
          </div>
        </div>

        {/* Component Selector Pills */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-300 block">Select Target Cloud Architecture Component:</label>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
            {[
              { id: 'bigtable', name: 'Cloud Bigtable', icon: Database, lang: 'typescript' },
              { id: 'spanner', name: 'Cloud Spanner', icon: Server, lang: 'sql' },
              { id: 'bigquery_geo', name: 'BigQuery Geo', icon: Globe, lang: 'sql' },
              { id: 'colossus_gcs', name: 'Colossus GCS', icon: HardDrive, lang: 'typescript' },
              { id: 'cloud_nat', name: 'VPC Cloud NAT', icon: ShieldCheck, lang: 'terraform' },
              { id: 'terraform_all', name: 'Full Terraform', icon: Layers, lang: 'terraform' },
            ].map((comp) => {
              const Icon = comp.icon;
              const isSelected = selectedComponent === comp.id;
              return (
                <button
                  key={comp.id}
                  onClick={() => {
                    setSelectedComponent(comp.id as any);
                    setSelectedLanguage(comp.lang as any);
                    handleGenerateCode(comp.id as any, comp.lang as any);
                  }}
                  className={`p-3 rounded-xl border text-left transition-all flex flex-col justify-between gap-1.5 ${
                    isSelected
                      ? 'bg-purple-950/80 border-purple-500 text-white ring-1 ring-purple-500 shadow-md'
                      : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isSelected ? 'text-purple-400' : 'text-slate-500'}`} />
                  <span className="text-xs font-bold block">{comp.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Custom Prompt Input & Language Bar */}
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1">
            <input
              type="text"
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
              placeholder="e.g. Include multi-region replication for India ($104/mo) and Global ($1,000/mo) tiers..."
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:border-purple-500 outline-none"
            />
          </div>
          <div className="flex items-center gap-2">
            <select
              value={selectedLanguage}
              onChange={(e: any) => setSelectedLanguage(e.target.value)}
              className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white focus:border-purple-500 outline-none font-mono"
            >
              <option value="typescript">TypeScript (GCP SDK)</option>
              <option value="terraform">Terraform (HCL)</option>
              <option value="sql">SQL (Standard SQL)</option>
              <option value="python">Python (google-cloud)</option>
            </select>
            <button
              onClick={() => handleGenerateCode()}
              disabled={isGenerating}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs transition-colors shrink-0 shadow-md"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Generating...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Generate Code</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Code Output Viewer */}
        <div className="relative rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden shadow-inner">
          <div className="bg-slate-900/90 px-4 py-2 border-b border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <Terminal className="w-3.5 h-3.5 text-purple-400" />
              <span className="font-mono text-slate-300 font-semibold uppercase">{selectedLanguage} Output</span>
              <span>•</span>
              <span className="text-[11px] font-mono text-purple-300">Generated by Gemini 2.5 Pro</span>
            </div>
            <button
              onClick={handleCopyCode}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-mono transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy Code'}</span>
            </button>
          </div>

          <pre className="p-4 text-xs font-mono text-slate-200 overflow-x-auto max-h-[420px] leading-relaxed whitespace-pre-wrap selection:bg-purple-900">
            {generatedCode}
          </pre>
        </div>
      </div>

      {/* Part 2: Open Source Healthcare Cloud Datasets */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Globe className="w-5 h-5 text-cyan-400" />
              <span>Open Source Cloud Healthcare Datasets</span>
            </h3>
            <p className="text-xs text-slate-400">
              Integrated open datasets for training, spatial routing, and clinical benchmark verification
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {datasets.map((ds) => (
            <div
              key={ds.id}
              className="bg-slate-950/80 rounded-xl p-4 border border-slate-800 flex flex-col justify-between gap-3"
            >
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-cyan-300 border border-slate-700">
                  {ds.category}
                </span>
                <h4 className="text-sm font-bold text-white mt-2 mb-1">{ds.name}</h4>
                <p className="text-xs text-slate-400 mb-3">{ds.description}</p>
                <div className="space-y-1 text-[11px] font-mono bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                  <div className="text-slate-400">
                    Records: <span className="text-white font-bold">{ds.recordsCount}</span>
                  </div>
                  <div className="text-slate-400">
                    License: <span className="text-emerald-400">{ds.license}</span>
                  </div>
                  <div className="text-slate-400">
                    Format: <span className="text-purple-300">{ds.format}</span>
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-900 flex items-center justify-between">
                <span className="text-[10px] text-slate-500 font-mono">Ready for BigQuery &amp; Bigtable</span>
                <span className="text-xs font-bold text-cyan-400 flex items-center gap-1">
                  Active Feed
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
