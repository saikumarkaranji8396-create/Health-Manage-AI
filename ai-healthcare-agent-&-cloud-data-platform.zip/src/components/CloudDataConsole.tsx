import React, { useState, useEffect } from 'react';
import {
  Database,
  Layers,
  Server,
  Cloud,
  HardDrive,
  ShieldCheck,
  Zap,
  Globe,
  RefreshCw,
  Terminal,
  Play,
  CheckCircle2,
  Lock,
  ArrowRight,
  ExternalLink,
  Code,
  FileText,
  Activity,
  Cpu,
  Share2,
  Plus,
} from 'lucide-react';
import {
  BigtableInstanceStatus,
  SpannerInstanceStatus,
  BigQueryFederationStatus,
  ColossusGcsFile,
  VpcCloudNatStatus,
} from '../types';

export const CloudDataConsole: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'bigtable' | 'spanner' | 'bigquery' | 'colossus' | 'vpc_nat'>('bigtable');

  // Bigtable state
  const [bigtableStatus, setBigtableStatus] = useState<BigtableInstanceStatus | null>(null);
  const [isWritingBigtable, setIsWritingBigtable] = useState(false);
  const [bigtableWriteResult, setBigtableWriteResult] = useState<any>(null);

  // Spanner state
  const [spannerStatus, setSpannerStatus] = useState<SpannerInstanceStatus | null>(null);

  // BigQuery Geo state
  const [bigqueryStatus, setBigqueryStatus] = useState<BigQueryFederationStatus | null>(null);
  const [queryRunning, setQueryRunning] = useState(false);

  // Colossus GCS state
  const [gcsFiles, setGcsFiles] = useState<ColossusGcsFile[]>([]);
  const [isUploadingGcs, setIsUploadingGcs] = useState(false);

  // VPC & Cloud NAT state
  const [natStatus, setNatStatus] = useState<VpcCloudNatStatus | null>(null);
  const [isTestingEgress, setIsTestingEgress] = useState(false);
  const [egressTestResult, setEgressTestResult] = useState<string | null>(null);

  // Load Cloud Data initial states
  useEffect(() => {
    fetchBigtable();
    fetchSpanner();
    fetchBigQueryGeo();
    fetchColossusFiles();
    fetchVpcNat();
  }, []);

  const fetchBigtable = async () => {
    try {
      const res = await fetch('/api/cloud-data/bigtable-telemetry');
      const data = await res.json();
      if (data.success) setBigtableStatus(data.instance);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchSpanner = async () => {
    try {
      const res = await fetch('/api/cloud-data/spanner-tx');
      const data = await res.json();
      if (data.success) setSpannerStatus(data.instance);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchBigQueryGeo = async () => {
    try {
      setQueryRunning(true);
      const res = await fetch('/api/cloud-data/bigquery-geo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lat: 37.7749, lng: -122.4194 }),
      });
      const data = await res.json();
      if (data.success) setBigqueryStatus(data);
    } catch (e) {
      console.error(e);
    } finally {
      setQueryRunning(false);
    }
  };

  const fetchColossusFiles = async () => {
    try {
      const res = await fetch('/api/cloud-data/colossus-files');
      const data = await res.json();
      if (data.success) setGcsFiles(data.files);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchVpcNat = async () => {
    try {
      const res = await fetch('/api/cloud-data/vpc-nat-status');
      const data = await res.json();
      if (data.success) setNatStatus(data.status);
    } catch (e) {
      console.error(e);
    }
  };

  // Simulate Rapid Bigtable NoSQL Write
  const handleSimulateBigtableWrite = async () => {
    setIsWritingBigtable(true);
    setBigtableWriteResult(null);
    try {
      const res = await fetch('/api/cloud-data/bigtable-telemetry/write', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          hospitalId: 'HOSP-IN-DELHI-01',
          patientId: `PAT-${Math.floor(1000 + Math.random() * 9000)}`,
          bpm: Math.floor(70 + Math.random() * 50),
          spo2: Math.floor(95 + Math.random() * 5),
          bleedingRate: '0.45_ml_sec',
        }),
      });
      const data = await res.json();
      setBigtableWriteResult(data);
      fetchBigtable();
    } catch (e) {
      console.error(e);
    } finally {
      setIsWritingBigtable(false);
    }
  };

  // Simulate Colossus GCS Upload
  const handleSimulateColossusUpload = async () => {
    setIsUploadingGcs(true);
    try {
      const scanId = Math.random().toString(36).substring(2, 7).toUpperCase();
      await fetch('/api/cloud-data/colossus-files/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          objectName: `reports/2026/09/SURGICAL-TRAUMA-SCAN-${scanId}.pdf`,
          contentType: 'application/pdf',
          sizeBytes: 154000,
        }),
      });
      fetchColossusFiles();
    } catch (e) {
      console.error(e);
    } finally {
      setIsUploadingGcs(false);
    }
  };

  // Simulate Cloud NAT Egress Ping
  const handleTestNatEgress = () => {
    setIsTestingEgress(true);
    setEgressTestResult(null);
    setTimeout(() => {
      setIsTestingEgress(false);
      setEgressTestResult('✓ Egress Request OK: Outbound packet to https://packages.cloud.google.com/ translated via Cloud NAT Gateway (NAT IP: 34.120.45.19). Inbound ports completely blocked (Zero-Ingress).');
    }, 1200);
  };

  return (
    <div className="space-y-6">
      {/* Console Top Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-blue-950 text-blue-300 border border-blue-800 mb-2">
              <Cloud className="w-3.5 h-3.5 text-blue-400" />
              <span>Google Cloud Platform Enterprise Architecture Console</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              Cloud Data &amp; Infrastructure Engine
            </h2>
            <p className="text-xs text-slate-300 mt-1 max-w-2xl">
              Live provisioned architecture: Cloud Bigtable for rapid NoSQL streaming, Cloud Spanner for transactional subscriptions, BigQuery Geospatial with Spanner Federation, Colossus-backed GCS, and private VPC Cloud NAT.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-950 p-2 rounded-xl border border-slate-800 text-xs">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-slate-300 font-mono">Cluster Status: All Systems Operational</span>
          </div>
        </div>

        {/* Console Sub-navigation Tabs */}
        <div className="mt-6 pt-5 border-t border-slate-800 flex items-center overflow-x-auto gap-2 no-scrollbar">
          <button
            onClick={() => setActiveSubTab('bigtable')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
              activeSubTab === 'bigtable'
                ? 'bg-blue-600 text-white shadow-lg'
                : 'bg-slate-950 text-slate-300 hover:bg-slate-800 border border-slate-800'
            }`}
          >
            <Database className="w-3.5 h-3.5 text-cyan-300" />
            <span>1. Cloud Bigtable (Rapid NoSQL)</span>
          </button>

          <button
            onClick={() => setActiveSubTab('spanner')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
              activeSubTab === 'spanner'
                ? 'bg-blue-600 text-white shadow-lg'
                : 'bg-slate-950 text-slate-300 hover:bg-slate-800 border border-slate-800'
            }`}
          >
            <Server className="w-3.5 h-3.5 text-emerald-300" />
            <span>2. Cloud Spanner (Transactional DB)</span>
          </button>

          <button
            onClick={() => setActiveSubTab('bigquery')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
              activeSubTab === 'bigquery'
                ? 'bg-blue-600 text-white shadow-lg'
                : 'bg-slate-950 text-slate-300 hover:bg-slate-800 border border-slate-800'
            }`}
          >
            <Globe className="w-3.5 h-3.5 text-amber-300" />
            <span>3. BigQuery Geo &amp; Spanner Federation</span>
          </button>

          <button
            onClick={() => setActiveSubTab('colossus')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
              activeSubTab === 'colossus'
                ? 'bg-blue-600 text-white shadow-lg'
                : 'bg-slate-950 text-slate-300 hover:bg-slate-800 border border-slate-800'
            }`}
          >
            <HardDrive className="w-3.5 h-3.5 text-purple-300" />
            <span>4. Colossus GCS File Vault</span>
          </button>

          <button
            onClick={() => setActiveSubTab('vpc_nat')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
              activeSubTab === 'vpc_nat'
                ? 'bg-blue-600 text-white shadow-lg'
                : 'bg-slate-950 text-slate-300 hover:bg-slate-800 border border-slate-800'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-rose-300" />
            <span>5. VPC &amp; Cloud NAT Gateway</span>
          </button>
        </div>
      </div>

      {/* ====================================================================== */}
      {/* 1. CLOUD BIGTABLE TAB */}
      {/* ====================================================================== */}
      {activeSubTab === 'bigtable' && (
        <div className="space-y-6">
          {/* Architecture Spec Card */}
          <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
              <div>
                <span className="text-[10px] font-mono font-bold text-cyan-400 uppercase tracking-wider">
                  Requirement: High-Throughput Rapid NoSQL Reads/Writes
                </span>
                <h3 className="text-lg font-bold text-white flex items-center gap-2 mt-0.5">
                  <Database className="w-5 h-5 text-cyan-400" />
                  <span>Cloud Bigtable: Patient Video &amp; Sensor Telemetry Ingest</span>
                </h3>
              </div>
              <button
                onClick={handleSimulateBigtableWrite}
                disabled={isWritingBigtable}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-md transition-colors"
              >
                <Zap className={`w-4 h-4 ${isWritingBigtable ? 'animate-spin' : ''}`} />
                <span>Simulate High-Throughput Write (&lt;3ms)</span>
              </button>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block">INSTANCE &amp; STORAGE</span>
                <div className="text-sm font-bold text-white font-mono">triage-telemetry-prod</div>
                <span className="text-[10px] text-cyan-400">3 Nodes • SSD Storage</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block">READ THROUGHPUT</span>
                <div className="text-sm font-bold text-emerald-400 font-mono">14,250 QPS</div>
                <span className="text-[10px] text-slate-400">P99 Latency: 3.4 ms</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block">WRITE THROUGHPUT</span>
                <div className="text-sm font-bold text-cyan-400 font-mono">8,900 QPS</div>
                <span className="text-[10px] text-slate-400">High-volume vitals ingest</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block">MULTI-CLUSTER</span>
                <div className="text-sm font-bold text-amber-400 font-mono">asia-south1 &amp; us-central1</div>
                <span className="text-[10px] text-slate-400">Active-Active Replication</span>
              </div>
            </div>

            {/* Row-Key Strategy Explainer */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-300">Anti-Hotspotting Row-Key Design:</span>
                <span className="font-mono text-cyan-300 text-[11px]">[HOSPITAL_ID]#[PATIENT_ID]#[REVERSE_TIMESTAMP]</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                By appending a reverse timestamp (<code className="text-slate-300">Number.MAX_SAFE_INTEGER - Date.now()</code>), latest patient heart rate, SpO2, and bleeding flux rate are read sequentially from the head of the tablet partition without hotspotting Bigtable tablet servers.
              </p>
            </div>

            {/* Write Result Alert */}
            {bigtableWriteResult && (
              <div className="bg-cyan-950/60 border border-cyan-500/80 p-3 rounded-xl text-xs text-cyan-200 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>
                    Successfully committed NoSQL mutation in <strong>{bigtableWriteResult.writeLatencyMs}ms</strong> to row <code className="text-white font-mono text-[10px]">{bigtableWriteResult.rowKey}</code>
                  </span>
                </div>
              </div>
            )}

            {/* Sample Bigtable Rows */}
            <div>
              <h4 className="text-xs font-bold text-slate-300 mb-2">Live Bigtable Ingest Stream (Recent 4 Rows):</h4>
              <div className="bg-slate-950 rounded-xl border border-slate-800 overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-slate-900/80 text-slate-400 text-[10px]">
                    <tr>
                      <th className="p-2.5">ROW KEY</th>
                      <th className="p-2.5">COLUMN FAMILY</th>
                      <th className="p-2.5">QUALIFIER</th>
                      <th className="p-2.5">VALUE</th>
                      <th className="p-2.5">INGEST TIME</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80 text-slate-300">
                    {bigtableStatus?.sampleRows?.map((row, idx) => (
                      <tr key={idx} className="hover:bg-slate-900/50">
                        <td className="p-2.5 text-cyan-300 truncate max-w-[200px]">{row.rowKey}</td>
                        <td className="p-2.5 text-amber-300">{row.columnFamily}</td>
                        <td className="p-2.5 text-slate-200">{row.qualifier}</td>
                        <td className="p-2.5 text-emerald-400 font-bold">{row.value}</td>
                        <td className="p-2.5 text-slate-400 text-[10px]">{new Date(row.timestamp).toLocaleTimeString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ====================================================================== */}
      {/* 2. CLOUD SPANNER TAB */}
      {/* ====================================================================== */}
      {activeSubTab === 'spanner' && (
        <div className="space-y-6">
          <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
              <div>
                <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-wider">
                  Requirement: Horizontally Scalable Relational Database for Transactional Data
                </span>
                <h3 className="text-lg font-bold text-white flex items-center gap-2 mt-0.5">
                  <Server className="w-5 h-5 text-emerald-400" />
                  <span>Cloud Spanner: Hospital Subscriptions &amp; ACID Billing Ledger</span>
                </h3>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                SLA: 99.999% • External Consistency
              </span>
            </div>

            {/* Spanner Configuration Overview */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block">SPANNER INSTANCE</span>
                <div className="text-sm font-bold text-white font-mono">healthcare-transactions-global</div>
                <span className="text-[10px] text-emerald-400">Dialect: GOOGLE_STANDARD_SQL</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block">TOPOLOGY</span>
                <div className="text-sm font-bold text-white font-mono">Multi-Region &amp; Regional</div>
                <span className="text-[10px] text-slate-400">asia-south1 (IN) &amp; us-central1</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block">INTERLEAVED SCHEMAS</span>
                <div className="text-sm font-bold text-cyan-400 font-mono">Hospitals → Subscriptions</div>
                <span className="text-[10px] text-slate-400">Colocated Parent-Child Partitions</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block">TRUE-TIME API</span>
                <div className="text-sm font-bold text-purple-400 font-mono">Strict Serializability</div>
                <span className="text-[10px] text-slate-400">Atomic Multi-Region Commits</span>
              </div>
            </div>

            {/* DDL Schema Viewer */}
            <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <Code className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Interleaved DDL Definition:</span>
                </span>
                <span className="text-[10px] text-slate-500 font-mono">Spanner Schema DDL</span>
              </div>
              <pre className="p-3 bg-slate-900 rounded-lg text-[11px] font-mono text-emerald-300 overflow-x-auto">
{`CREATE TABLE Hospitals (
  hospital_id STRING(64) NOT NULL,
  hospital_name STRING(256) NOT NULL,
  country_code STRING(10) NOT NULL,
  latitude FLOAT64 NOT NULL,
  longitude FLOAT64 NOT NULL,
  trauma_level STRING(64) NOT NULL,
  bed_capacity INT64 NOT NULL
) PRIMARY KEY (hospital_id);

CREATE TABLE Subscriptions (
  hospital_id STRING(64) NOT NULL,
  subscription_id STRING(64) NOT NULL,
  plan_tier STRING(64) NOT NULL, -- 'INDIA_104' ($104/mo) OR 'GLOBAL_1000' ($1,000/mo)
  monthly_rate_usd NUMERIC NOT NULL,
  status STRING(32) NOT NULL
) PRIMARY KEY (hospital_id, subscription_id),
  INTERLEAVE IN PARENT Hospitals ON DELETE CASCADE;`}
              </pre>
            </div>

            {/* Recent ACID Transactions */}
            <div>
              <h4 className="text-xs font-bold text-slate-300 mb-2">Live Cloud Spanner Transaction Log:</h4>
              <div className="bg-slate-950 rounded-xl border border-slate-800 overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-slate-900/80 text-slate-400 text-[10px]">
                    <tr>
                      <th className="p-2.5">TX ID</th>
                      <th className="p-2.5">OPERATION</th>
                      <th className="p-2.5">HOSPITAL ID</th>
                      <th className="p-2.5">AMOUNT (USD)</th>
                      <th className="p-2.5">ACID STATUS</th>
                      <th className="p-2.5">COMMIT TIME</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80 text-slate-300">
                    {spannerStatus?.sampleTransactions?.map((tx, idx) => (
                      <tr key={idx} className="hover:bg-slate-900/50">
                        <td className="p-2.5 text-cyan-300">{tx.txId}</td>
                        <td className="p-2.5 text-white font-bold">{tx.operation}</td>
                        <td className="p-2.5 text-slate-400">{tx.hospitalId}</td>
                        <td className="p-2.5 text-emerald-400 font-bold">${tx.amountUSD}</td>
                        <td className="p-2.5 text-emerald-400">● {tx.status}</td>
                        <td className="p-2.5 text-slate-400 text-[10px]">{new Date(tx.timestamp).toLocaleTimeString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ====================================================================== */}
      {/* 3. BIGQUERY GEOSPATIAL & SPANNER FEDERATION TAB */}
      {/* ====================================================================== */}
      {activeSubTab === 'bigquery' && (
        <div className="space-y-6">
          <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
              <div>
                <span className="text-[10px] font-mono font-bold text-amber-400 uppercase tracking-wider">
                  Requirement: BigQuery Dataset with GEOGRAPHY Column &amp; Spanner Federation
                </span>
                <h3 className="text-lg font-bold text-white flex items-center gap-2 mt-0.5">
                  <Globe className="w-5 h-5 text-amber-400" />
                  <span>BigQuery Geospatial Analytics &amp; Cloud Spanner Federation</span>
                </h3>
              </div>
              <button
                onClick={fetchBigQueryGeo}
                disabled={queryRunning}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold transition-colors"
              >
                <Play className={`w-3.5 h-3.5 ${queryRunning ? 'animate-spin' : ''}`} />
                <span>Run Federated Spatial Query</span>
              </button>
            </div>

            {/* Spec Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block">BIGQUERY DATASET</span>
                <div className="text-sm font-bold text-white font-mono">healthcare_geo_analytics</div>
                <span className="text-[10px] text-amber-400">Column: er_point GEOGRAPHY</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 sm:col-span-2">
                <span className="text-[10px] text-slate-500 block">SPANNER FEDERATION CONNECTION URI</span>
                <div className="text-xs font-bold text-cyan-300 font-mono truncate">
                  projects/healthcare-ai-core/locations/global/connections/spanner_federation
                </div>
                <span className="text-[10px] text-slate-400">Direct SQL over Spanner without ETL pipeline</span>
              </div>
            </div>

            {/* Federated SQL Query Block */}
            <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-slate-300 block">Federated Spatial SQL Query:</span>
              <pre className="p-3 bg-slate-900 rounded-lg text-[11px] font-mono text-amber-300 overflow-x-auto whitespace-pre-wrap">
{`SELECT
  spanner_hosp.hospital_id,
  spanner_hosp.hospital_name,
  spanner_sub.monthly_rate_usd,
  geo.er_point, -- GEOGRAPHY data type
  ST_DISTANCE(geo.er_point, ST_GEOGPOINT(@patient_lng, @patient_lat)) AS distance_meters
FROM
  EXTERNAL_QUERY(
    "projects/healthcare-ai-core/locations/global/connections/spanner_federation",
    "SELECT hospital_id, hospital_name, monthly_rate_usd FROM Hospitals JOIN Subscriptions USING (hospital_id)"
  ) AS spanner_hosp
JOIN
  \`healthcare_geo_analytics.hospital_coverage\` AS geo
ON
  spanner_hosp.hospital_id = geo.hospital_id
WHERE
  ST_DWITHIN(geo.er_point, ST_GEOGPOINT(@patient_lng, @patient_lat), 50000)
ORDER BY
  distance_meters ASC;`}
              </pre>
            </div>

            {/* Federated Results Table */}
            <div>
              <h4 className="text-xs font-bold text-slate-300 mb-2">Federated Query Results (Cloud Spanner Data Joined in BigQuery):</h4>
              <div className="bg-slate-950 rounded-xl border border-slate-800 overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-slate-900/80 text-slate-400 text-[10px]">
                    <tr>
                      <th className="p-2.5">HOSPITAL NAME</th>
                      <th className="p-2.5">GEOGRAPHY (ST_GEOGPOINT)</th>
                      <th className="p-2.5">MONTHLY RATE (SPANNER)</th>
                      <th className="p-2.5">GEODESIC DISTANCE</th>
                      <th className="p-2.5">TRAUMA STATUS</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80 text-slate-300">
                    {bigqueryStatus?.federatedResults?.map((r, idx) => (
                      <tr key={idx} className="hover:bg-slate-900/50">
                        <td className="p-2.5 text-white font-bold">{r.hospital_name}</td>
                        <td className="p-2.5 text-amber-300">{r.location_geography}</td>
                        <td className="p-2.5 text-emerald-400 font-bold">${r.monthly_fee_usd}/mo</td>
                        <td className="p-2.5 text-cyan-300">{(r.distance_meters / 1000).toFixed(1)} km ({r.distance_meters} m)</td>
                        <td className="p-2.5 text-slate-300">{r.trauma_level}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ====================================================================== */}
      {/* 4. COLOSSUS GCS FILE SYSTEM TAB */}
      {/* ====================================================================== */}
      {activeSubTab === 'colossus' && (
        <div className="space-y-6">
          <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
              <div>
                <span className="text-[10px] font-mono font-bold text-purple-400 uppercase tracking-wider">
                  Requirement: Standard Google Cloud Storage Bucket backed by Colossus
                </span>
                <h3 className="text-lg font-bold text-white flex items-center gap-2 mt-0.5">
                  <HardDrive className="w-5 h-5 text-purple-400" />
                  <span>Google Cloud Storage: Colossus-Backed Triage Vault</span>
                </h3>
              </div>
              <button
                onClick={handleSimulateColossusUpload}
                disabled={isUploadingGcs}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Simulate Surgical Report Ingest</span>
              </button>
            </div>

            {/* Colossus Explanation Callout */}
            <div className="bg-purple-950/40 border border-purple-800 rounded-xl p-4 text-xs space-y-1.5">
              <span className="font-bold text-purple-300">Colossus File System Architecture Note:</span>
              <p className="text-purple-200/90 leading-relaxed">
                Colossus is Google's cluster-level successor to GFS (Google File System), handling distributed data striping, Reed-Solomon erasure coding, and replication across datacenter disks. Google Cloud Storage (GCS) sits directly on top of Colossus to provide 99.999999999% (11 nines) annual durability for medical scans and patient video triage records.
              </p>
            </div>

            {/* GCS Bucket Details */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block">BUCKET URI</span>
                <div className="text-xs font-bold text-white font-mono truncate">gs://healthcare-colossus-triage-vault</div>
                <span className="text-[10px] text-purple-400">Class: STANDARD (Multi-Region)</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block">UNDERLYING ENGINE</span>
                <div className="text-xs font-bold text-purple-300 font-mono">Colossus Distributed Engine</div>
                <span className="text-[10px] text-slate-400">Sub-chunk parallel range reads</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block">LIFECYCLE RULES</span>
                <div className="text-xs font-bold text-emerald-400 font-mono">Coldline @ 180 Days</div>
                <span className="text-[10px] text-slate-400">7-Year HIPAA Retention</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block">SECURITY</span>
                <div className="text-xs font-bold text-cyan-400 font-mono">CMEK Encrypted</div>
                <span className="text-[10px] text-slate-400">V4 Signed URLs (15-min TTL)</span>
              </div>
            </div>

            {/* Bucket Objects List */}
            <div>
              <h4 className="text-xs font-bold text-slate-300 mb-2">Stored Bucket Objects (Colossus Chunks):</h4>
              <div className="bg-slate-950 rounded-xl border border-slate-800 overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-slate-900/80 text-slate-400 text-[10px]">
                    <tr>
                      <th className="p-2.5">OBJECT NAME</th>
                      <th className="p-2.5">STORAGE CLASS</th>
                      <th className="p-2.5">SIZE</th>
                      <th className="p-2.5">STORAGE SUBSYSTEM</th>
                      <th className="p-2.5">TIMESTAMP</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80 text-slate-300">
                    {gcsFiles.map((file) => (
                      <tr key={file.id} className="hover:bg-slate-900/50">
                        <td className="p-2.5 text-white font-semibold flex items-center gap-1.5">
                          <FileText className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                          <span>{file.objectName}</span>
                        </td>
                        <td className="p-2.5 text-cyan-300">{file.storageClass}</td>
                        <td className="p-2.5 text-slate-300">{(file.sizeBytes / 1024).toFixed(1)} KB</td>
                        <td className="p-2.5 text-purple-300 text-[10px]">{file.internalSubsystem}</td>
                        <td className="p-2.5 text-slate-400 text-[10px]">{new Date(file.uploadedAt).toLocaleTimeString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ====================================================================== */}
      {/* 5. VPC NETWORK & CLOUD NAT GATEWAY TAB */}
      {/* ====================================================================== */}
      {activeSubTab === 'vpc_nat' && (
        <div className="space-y-6">
          <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
              <div>
                <span className="text-[10px] font-mono font-bold text-rose-400 uppercase tracking-wider">
                  Requirement: VPC Network with Cloud NAT Gateway (Zero-Inbound Exposure)
                </span>
                <h3 className="text-lg font-bold text-white flex items-center gap-2 mt-0.5">
                  <ShieldCheck className="w-5 h-5 text-rose-400" />
                  <span>Private VPC Network &amp; Cloud NAT Gateway Security Mesh</span>
                </h3>
              </div>
              <button
                onClick={handleTestNatEgress}
                disabled={isTestingEgress}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-colors"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>{isTestingEgress ? 'Testing Outbound NAT Translation...' : 'Test Outbound Egress Download'}</span>
              </button>
            </div>

            {/* Security Architecture Diagram Banner */}
            <div className="bg-slate-950 p-4 rounded-xl border border-rose-900/50 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-rose-300">Zero-Trust Network Architecture:</span>
                <span className="px-2 py-0.5 rounded text-[10px] bg-rose-950 text-rose-200 border border-rose-800 font-mono font-bold">
                  ZERO PUBLIC IPs ON PRIVATE RESOURCES
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Hospital databases (Cloud Spanner) and compute instances operate on a strictly private subnet (<code className="text-cyan-300 font-mono">10.100.1.0/24</code>) with no external IP addresses. When downloading CVE patches, OS updates, or dispatching outbound emergency webhooks, traffic is routed through <strong>Cloud NAT</strong> with stateful source-IP translation. All unsolicited incoming connections from the internet are dropped at the border.
              </p>
            </div>

            {/* NAT Status Result Toast */}
            {egressTestResult && (
              <div className="bg-emerald-950/80 border border-emerald-500 p-3 rounded-xl text-xs text-emerald-200">
                {egressTestResult}
              </div>
            )}

            {/* VPC and NAT Specs */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block">VPC NETWORK</span>
                <div className="text-xs font-bold text-white font-mono truncate">hospital-secure-mesh-vpc</div>
                <span className="text-[10px] text-slate-400">Subnet: 10.100.1.0/24</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block">NAT GATEWAY</span>
                <div className="text-xs font-bold text-rose-400 font-mono truncate">nat-hospital-secure-gateway</div>
                <span className="text-[10px] text-slate-400">Router: cr-hospital-nat-router</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block">ALLOCATED NAT IPS</span>
                <div className="text-xs font-bold text-cyan-300 font-mono">34.120.45.19, .20</div>
                <span className="text-[10px] text-slate-400">Fixed Static Egress IPs</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block">ATTACK SURFACE</span>
                <div className="text-xs font-bold text-emerald-400 font-mono">0 Inbound Ports Open</div>
                <span className="text-[10px] text-slate-400">Stateful Connection Tracking</span>
              </div>
            </div>

            {/* Outbound Egress Traffic Log */}
            <div>
              <h4 className="text-xs font-bold text-slate-300 mb-2">Live Cloud NAT Outbound Egress Log (Secure Updates):</h4>
              <div className="bg-slate-950 rounded-xl border border-slate-800 overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-slate-900/80 text-slate-400 text-[10px]">
                    <tr>
                      <th className="p-2.5">DESTINATION</th>
                      <th className="p-2.5">PORT / PROTOCOL</th>
                      <th className="p-2.5">BYTES TRANSFERRED</th>
                      <th className="p-2.5">NAT TRANSLATION STATUS</th>
                      <th className="p-2.5">TIMESTAMP</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80 text-slate-300">
                    {natStatus?.recentOutboundEgressTraffic?.map((log, idx) => (
                      <tr key={idx} className="hover:bg-slate-900/50">
                        <td className="p-2.5 text-white font-semibold">{log.destination}</td>
                        <td className="p-2.5 text-cyan-300">{log.protocol}</td>
                        <td className="p-2.5 text-slate-300">{(log.bytesSent / 1024).toFixed(1)} KB</td>
                        <td className="p-2.5 text-emerald-400">● {log.status}</td>
                        <td className="p-2.5 text-slate-400 text-[10px]">{new Date(log.timestamp).toLocaleTimeString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
