import React, { useState } from 'react';
import {
  Building2,
  CheckCircle2,
  Globe,
  Sparkles,
  ShieldCheck,
  Zap,
  CreditCard,
  Plus,
  Clock,
  Phone,
  MapPin,
  Check,
  AlertCircle,
  Database,
  ExternalLink,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';
import { SubscribedHospital, SubscriptionCountry } from '../types';

interface HospitalSubscriptionsViewProps {
  hospitals: SubscribedHospital[];
  onAddHospital: (newHospital: any) => Promise<boolean>;
  onTriggerERAlert?: (hospital: SubscribedHospital) => void;
}

export const HospitalSubscriptionsView: React.FC<HospitalSubscriptionsViewProps> = ({
  hospitals,
  onAddHospital,
}) => {
  const [selectedCountry, setSelectedCountry] = useState<SubscriptionCountry>('IN');
  const [isSubscribingModalOpen, setIsSubscribingModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Form State
  const [formHospitalName, setFormHospitalName] = useState('');
  const [formLicense, setFormLicense] = useState('');
  const [formCountry, setFormCountry] = useState<SubscriptionCountry>('IN');
  const [formCity, setFormCity] = useState('');
  const [formAddress, setFormAddress] = useState('');
  const [formLat, setFormLat] = useState('28.5355');
  const [formLng, setFormLng] = useState('77.2910');
  const [formPhone, setFormPhone] = useState('+91 98765 43210');
  const [formEmail, setFormEmail] = useState('contact@hospital.org');
  const [formTraumaLevel, setFormTraumaLevel] = useState<'Level 1 Trauma Center' | 'Level 2 Regional ER' | 'Specialty Surgical Center'>('Level 1 Trauma Center');
  const [formBedCapacity, setFormBedCapacity] = useState('500');

  const isIndia = selectedCountry === 'IN';
  const currentMonthlyPrice = isIndia ? 104 : 1000;
  const currentMonthlyDisplay = isIndia ? '$104 / month (₹8,650 INR)' : '$1,000 / month USD';

  const handleCountryToggle = (country: SubscriptionCountry) => {
    setSelectedCountry(country);
    setFormCountry(country);
    if (country === 'IN') {
      setFormLat('28.5355');
      setFormLng('77.2910');
      setFormPhone('+91 11 2692 5858');
      setFormCity('New Delhi');
    } else {
      setFormLat('37.7749');
      setFormLng('-122.4194');
      setFormPhone('+1 (800) 555-0199');
      setFormCity('San Francisco');
    }
  };

  const handleSubmitSubscription = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formHospitalName || !formCity) return;
    setIsSubmitting(true);

    const payload = {
      hospitalName: formHospitalName,
      licenseNumber: formLicense,
      country: formCountry,
      city: formCity,
      address: formAddress || `${formCity} Health Campus`,
      lat: parseFloat(formLat) || (formCountry === 'IN' ? 28.5355 : 37.7749),
      lng: parseFloat(formLng) || (formCountry === 'IN' ? 77.2910 : -122.4194),
      contactEmail: formEmail,
      phone: formPhone,
      traumaLevel: formTraumaLevel,
      bedCapacity: parseInt(formBedCapacity) || 450,
    };

    const ok = await onAddHospital(payload);
    setIsSubmitting(false);
    if (ok) {
      setIsSubscribingModalOpen(false);
      setSuccessToast(`Hospital "${formHospitalName}" successfully subscribed at ${formCountry === 'IN' ? '$104/mo (India Tier)' : '$1,000/mo (Global Tier)'}!`);
      setTimeout(() => setSuccessToast(null), 5000);
      setFormHospitalName('');
    }
  };

  return (
    <div className="space-y-8">
      {/* Toast Notice */}
      {successToast && (
        <div className="bg-emerald-950 border border-emerald-500 text-emerald-200 px-4 py-3 rounded-xl text-xs flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{successToast}</span>
          </div>
          <button onClick={() => setSuccessToast(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Pricing Header Hero */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-emerald-950/40 to-slate-900 border border-emerald-500/30 p-6 sm:p-8 shadow-2xl">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-emerald-950 text-emerald-300 border border-emerald-700/60 shadow-inner">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>Hospital Partner Network • Live Triage &amp; Cloud Data</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Hospital Premium Subscriptions
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Connect your emergency hospital or trauma center directly to the AI Live Video Triage Agent.
              Receive instant surgical PDF briefs, direct Google Maps emergency routing, and high-throughput Bigtable patient streams.
            </p>
          </div>

          {/* Subscribe CTA Button */}
          <button
            onClick={() => setIsSubscribingModalOpen(true)}
            className="flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs sm:text-sm shadow-xl shadow-emerald-950/60 transition-transform active:scale-95 whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>Subscribe New Hospital</span>
          </button>
        </div>

        {/* Pricing Selector Tabs */}
        <div className="mt-8 pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-2xl border border-slate-800">
            <button
              onClick={() => handleCountryToggle('IN')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black transition-all ${
                selectedCountry === 'IN'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>🇮🇳 India Only</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800">
                $104 / mo
              </span>
            </button>
            <button
              onClick={() => handleCountryToggle('GLOBAL')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black transition-all ${
                selectedCountry === 'GLOBAL'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>🌐 All Other Countries (Global)</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800">
                $1,000 / mo
              </span>
            </button>
          </div>

          <div className="text-xs text-slate-400">
            Current Tier:{' '}
            <strong className="text-emerald-400 font-bold">{currentMonthlyDisplay}</strong>
          </div>
        </div>
      </div>

      {/* Tier Breakdown Cards (India vs Global) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* India Tier Card */}
        <div
          className={`rounded-2xl p-6 border transition-all relative flex flex-col justify-between ${
            selectedCountry === 'IN'
              ? 'bg-slate-900 border-emerald-500 shadow-xl ring-2 ring-emerald-500/50'
              : 'bg-slate-900/50 border-slate-800 opacity-80'
          }`}
        >
          {selectedCountry === 'IN' && (
            <span className="absolute -top-3 right-6 px-3 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-500 text-slate-950 shadow-sm">
              Selected Country Tier
            </span>
          )}
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                🇮🇳 Regional Tier • India
              </span>
              <span className="text-[11px] text-slate-400">Monthly Billing</span>
            </div>
            <div className="flex items-baseline gap-2 mb-2">
              <span className="text-3xl font-black text-white">$104</span>
              <span className="text-xs text-slate-400">/ month</span>
              <span className="text-xs font-mono text-emerald-400 ml-2">(₹8,650 INR)</span>
            </div>
            <p className="text-xs text-slate-300 mb-5">
              Specially indexed for healthcare providers, medical colleges, and regional trauma centers across India.
            </p>

            <ul className="space-y-2.5 text-xs text-slate-200">
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Instant Emergency Priority:</strong> Patients within 35 km automatically routed to your ER</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Cloud Bigtable Stream:</strong> Sub-millisecond sensor &amp; optical telemetry feed (asia-south1)</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Cloud Spanner ACID Ledger:</strong> Automated bed availability sync &amp; multi-surgeon access</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>BigQuery Geospatial Analytics:</strong> Dynamic GEOGRAPHY polygon catchment analysis</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Colossus GCS Storage:</strong> Encrypted medical report archives &amp; high-res video captures</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Private VPC + Cloud NAT:</strong> Secure zero-inbound HIPAA hospital connectivity</span>
              </li>
            </ul>
          </div>

          <button
            onClick={() => {
              setSelectedCountry('IN');
              setFormCountry('IN');
              setIsSubscribingModalOpen(true);
            }}
            className="mt-6 w-full py-2.5 rounded-xl font-bold text-xs bg-emerald-600 hover:bg-emerald-500 text-white transition-colors"
          >
            Onboard India Hospital ($104/mo)
          </button>
        </div>

        {/* Global Tier Card */}
        <div
          className={`rounded-2xl p-6 border transition-all relative flex flex-col justify-between ${
            selectedCountry === 'GLOBAL'
              ? 'bg-slate-900 border-emerald-500 shadow-xl ring-2 ring-emerald-500/50'
              : 'bg-slate-900/50 border-slate-800 opacity-80'
          }`}
        >
          {selectedCountry === 'GLOBAL' && (
            <span className="absolute -top-3 right-6 px-3 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-500 text-slate-950 shadow-sm">
              Selected Country Tier
            </span>
          )}
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-blue-950 text-blue-300 border border-blue-800">
                🌐 Global Enterprise • All Other Countries
              </span>
              <span className="text-[11px] text-slate-400">Monthly Billing</span>
            </div>
            <div className="flex items-baseline gap-2 mb-2">
              <span className="text-3xl font-black text-white">$1,000</span>
              <span className="text-xs text-slate-400">/ month USD</span>
            </div>
            <p className="text-xs text-slate-300 mb-5">
              Comprehensive global integration for hospitals, university health networks, and trauma centers in USA, UK, EU, Singapore, etc.
            </p>

            <ul className="space-y-2.5 text-xs text-slate-200">
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Global Multi-Region Routing:</strong> Turn-by-Turn Google Maps integration for ER &amp; Trauma 1</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Multi-Cluster Bigtable:</strong> High-throughput replicated telemetry (&lt;3ms p99 worldwide)</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Cloud Spanner Multi-Region:</strong> 99.999% availability horizontally scalable transactions</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>BigQuery Federation Connection:</strong> Query Spanner records directly via BigQuery SQL</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Colossus Multi-Region Vault:</strong> Unlimited surgical scan archives with 7-year retention policy</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Dedicated Cloud NAT Mesh:</strong> Egress whitelist and automated security patching</span>
              </li>
            </ul>
          </div>

          <button
            onClick={() => {
              setSelectedCountry('GLOBAL');
              setFormCountry('GLOBAL');
              setIsSubscribingModalOpen(true);
            }}
            className="mt-6 w-full py-2.5 rounded-xl font-bold text-xs bg-cyan-600 hover:bg-cyan-500 text-white transition-colors"
          >
            Onboard Global Hospital ($1,000/mo)
          </button>
        </div>
      </div>

      {/* Subscribed Hospitals Directory */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Building2 className="w-5 h-5 text-emerald-400" />
              <span>Active Subscribed Partner Hospitals</span>
              <span className="px-2 py-0.5 rounded-full text-xs font-mono bg-slate-800 text-cyan-300 border border-slate-700">
                {hospitals.length} Connected
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Live hospital tenants receiving automated triage dispatches and telemetry streams
            </p>
          </div>

          <button
            onClick={() => setIsSubscribingModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors self-start sm:self-auto"
          >
            <Plus className="w-3.5 h-3.5 text-emerald-400" />
            <span>Add Partner Hospital</span>
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {hospitals.map((hosp) => {
            const isInd = hosp.country === 'IN';
            return (
              <div
                key={hosp.id}
                className="bg-slate-950/80 rounded-xl p-4 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between gap-3 space-y-2"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider ${
                        isInd
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-blue-950 text-blue-300 border border-blue-800'
                      }`}
                    >
                      {isInd ? '🇮🇳 India Tier ($104/mo)' : '🌐 Global Tier ($1,000/mo)'}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-900/60 text-emerald-300 border border-emerald-700">
                      ● {hosp.activeStatus}
                    </span>
                  </div>

                  <h4 className="text-sm font-bold text-white mb-1 flex items-center justify-between">
                    <span>{hosp.hospitalName}</span>
                  </h4>
                  <p className="text-xs text-slate-400 flex items-center gap-1.5 mb-2">
                    <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                    <span>{hosp.address}</span>
                  </p>

                  <div className="grid grid-cols-2 gap-2 text-[11px] bg-slate-900/90 p-2.5 rounded-lg border border-slate-800">
                    <div>
                      <span className="text-slate-500 block text-[10px]">TRAUMA RATING</span>
                      <span className="text-slate-200 font-semibold">{hosp.traumaLevel}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px]">BED CAPACITY</span>
                      <span className="text-cyan-300 font-semibold">{hosp.bedCapacity} Beds</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px]">AVG ER RESPONSE</span>
                      <span className="text-emerald-400 font-bold">{hosp.stats.avgERResponseMinutes} mins</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px]">DISPATCHED SCANS</span>
                      <span className="text-white font-bold">{hosp.stats.emergencyCasesDispatched} Cases</span>
                    </div>
                  </div>
                </div>

                {/* Cloud Tenant Footprint */}
                <div className="pt-2 border-t border-slate-900 flex flex-wrap items-center justify-between text-[10px] font-mono text-slate-400 gap-2">
                  <div className="flex items-center gap-1.5">
                    <Database className="w-3 h-3 text-cyan-400" />
                    <span>Spanner: {hosp.spannerTenantId}</span>
                  </div>
                  <div className="flex items-center gap-1 text-slate-300">
                    <span>Rate:</span>
                    <strong className="text-emerald-400">
                      ${hosp.subscriptionMonthlyRateUSD}/mo
                    </strong>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Subscribe Hospital Modal */}
      {isSubscribingModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-xl bg-slate-900 border border-emerald-500/80 rounded-2xl shadow-2xl overflow-hidden my-auto">
            <div className="bg-emerald-950/80 border-b border-emerald-800 px-5 py-3.5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-emerald-400" />
                <h3 className="text-sm sm:text-base font-bold text-white">
                  Onboard Hospital to AI Healthcare Triage Network
                </h3>
              </div>
              <button
                onClick={() => setIsSubscribingModalOpen(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitSubscription} className="p-5 space-y-4 text-xs">
              {/* Country Selection */}
              <div>
                <label className="font-semibold text-slate-300 block mb-1.5">
                  Select Country &amp; Monthly Subscription Rate:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setFormCountry('IN');
                      setFormCity('New Delhi');
                      setFormLat('28.5355');
                      setFormLng('77.2910');
                      setFormPhone('+91 11 2692 5858');
                    }}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      formCountry === 'IN'
                        ? 'bg-emerald-950/80 border-emerald-500 text-white ring-1 ring-emerald-500'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    <span className="font-bold block text-sm text-emerald-400">🇮🇳 India</span>
                    <span className="text-[11px] block mt-0.5">$104 / month (₹8,650)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setFormCountry('GLOBAL');
                      setFormCity('San Francisco');
                      setFormLat('37.7749');
                      setFormLng('-122.4194');
                      setFormPhone('+1 (800) 555-0199');
                    }}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      formCountry === 'GLOBAL'
                        ? 'bg-cyan-950/80 border-cyan-500 text-white ring-1 ring-cyan-500'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    <span className="font-bold block text-sm text-cyan-400">🌐 Global (All other countries)</span>
                    <span className="text-[11px] block mt-0.5">$1,000 / month USD</span>
                  </button>
                </div>
              </div>

              {/* Hospital Name & License */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-300 block mb-1">Hospital / Medical Center Name *</label>
                  <input
                    type="text"
                    required
                    value={formHospitalName}
                    onChange={(e) => setFormHospitalName(e.target.value)}
                    placeholder="e.g. City General Trauma Center"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:border-emerald-500 outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-300 block mb-1">State / National License Number</label>
                  <input
                    type="text"
                    value={formLicense}
                    onChange={(e) => setFormLicense(e.target.value)}
                    placeholder="e.g. NABH-2026-X992"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:border-emerald-500 outline-none"
                  />
                </div>
              </div>

              {/* City & Address */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-300 block mb-1">City / Metropolitan Area *</label>
                  <input
                    type="text"
                    required
                    value={formCity}
                    onChange={(e) => setFormCity(e.target.value)}
                    placeholder="e.g. New Delhi, Mumbai, or San Francisco"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:border-emerald-500 outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-300 block mb-1">Emergency Department Phone</label>
                  <input
                    type="text"
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    placeholder="e.g. +91 11 2692 5858"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:border-emerald-500 outline-none"
                  />
                </div>
              </div>

              {/* Lat / Lng for BigQuery Geospatial */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-300 block mb-1">Latitude (GEOGRAPHY point)</label>
                  <input
                    type="text"
                    value={formLat}
                    onChange={(e) => setFormLat(e.target.value)}
                    placeholder="28.5355"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:border-emerald-500 outline-none font-mono"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-300 block mb-1">Longitude (GEOGRAPHY point)</label>
                  <input
                    type="text"
                    value={formLng}
                    onChange={(e) => setFormLng(e.target.value)}
                    placeholder="77.2910"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:border-emerald-500 outline-none font-mono"
                  />
                </div>
              </div>

              {/* Bed Capacity & Trauma Level */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-300 block mb-1">Trauma Accreditation Level</label>
                  <select
                    value={formTraumaLevel}
                    onChange={(e: any) => setFormTraumaLevel(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:border-emerald-500 outline-none"
                  >
                    <option value="Level 1 Trauma Center">Level 1 Trauma Center</option>
                    <option value="Level 2 Regional ER">Level 2 Regional ER</option>
                    <option value="Specialty Surgical Center">Specialty Surgical Center</option>
                  </select>
                </div>
                <div>
                  <label className="font-semibold text-slate-300 block mb-1">Bed Capacity</label>
                  <input
                    type="number"
                    value={formBedCapacity}
                    onChange={(e) => setFormBedCapacity(e.target.value)}
                    placeholder="500"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:border-emerald-500 outline-none"
                  />
                </div>
              </div>

              {/* Pricing Confirmation Notice */}
              <div className="p-3 bg-emerald-950/40 border border-emerald-800 rounded-xl text-emerald-200 text-xs flex items-center justify-between">
                <div>
                  <span className="font-bold">Subscription Monthly Fee:</span>{' '}
                  <span className="font-mono">{formCountry === 'IN' ? '$104 / month (India Only)' : '$1,000 / month (Global)'}</span>
                </div>
                <span className="text-[10px] text-emerald-400 font-mono">ACID Spanner Ledger</span>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsSubscribingModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition-colors flex items-center gap-1.5"
                >
                  {isSubmitting ? 'Provisioning Cloud Spanner & Bigtable...' : 'Confirm Subscription & Activate'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
