import React, { useState } from 'react';
import {
  AlertOctagon,
  CheckCircle2,
  Navigation,
  FileText,
  Hospital,
  MapPin,
  Clock,
  Phone,
  UserCheck,
  Download,
  ExternalLink,
  ShieldCheck,
  AlertTriangle,
  Stethoscope,
  Activity,
  ChevronRight,
  Eye,
  Building2,
  Database,
} from 'lucide-react';
import { ScanAnalysisResult, UserLocation } from '../types';
import { generateMedicalReportPDF } from '../utils/pdfGenerator';
import { MedicalReportModal } from './MedicalReportModal';

interface TriageResultViewProps {
  result: ScanAnalysisResult;
  userLocation: UserLocation | null;
  onNewScan: () => void;
  onNavigateToSubscriptions?: () => void;
}

export const TriageResultView: React.FC<TriageResultViewProps> = ({
  result,
  userLocation,
  onNewScan,
  onNavigateToSubscriptions,
}) => {
  const isEmergency = result.scenario === 'EMERGENCY';
  const [showReportModal, setShowReportModal] = useState<boolean>(false);

  const handleDownloadPDF = () => {
    if (result.surgicalMedicalReport) {
      generateMedicalReportPDF(result.surgicalMedicalReport, result.nearestHospitalER);
    }
  };

  const handleLaunchGoogleMaps = (url?: string) => {
    if (url) {
      window.open(url, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Triage Alert Banner */}
      <div
        className={`rounded-2xl p-5 sm:p-6 border shadow-xl transition-all ${
          isEmergency
            ? 'bg-gradient-to-br from-rose-950/90 via-red-900/60 to-slate-900 border-rose-600 shadow-rose-950/50 ring-2 ring-rose-500/80 animate-pulse-subtle'
            : 'bg-gradient-to-br from-teal-950/90 via-slate-900 to-slate-900 border-emerald-500/80 shadow-teal-950/40'
        }`}
      >
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div
              className={`p-3 rounded-xl flex items-center justify-center text-white shadow-lg ${
                isEmergency ? 'bg-rose-600 animate-bounce' : 'bg-emerald-600'
              }`}
            >
              {isEmergency ? (
                <AlertOctagon className="w-8 h-8" />
              ) : (
                <CheckCircle2 className="w-8 h-8" />
              )}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-1">
                <span
                  className={`px-2.5 py-0.5 rounded-full text-xs font-black uppercase tracking-wider ${
                    isEmergency
                      ? 'bg-rose-500 text-white shadow-sm'
                      : 'bg-emerald-500 text-slate-950 font-bold'
                  }`}
                >
                  {isEmergency
                    ? 'SCENARIO 2: CRITICAL EMERGENCY CASE'
                    : 'SCENARIO 1: ROUTINE DIAGNOSIS'}
                </span>
                <span className="px-2 py-0.5 rounded text-xs font-mono font-bold bg-slate-800 text-slate-300 border border-slate-700">
                  Severity Score: {result.severityScore} / 10
                </span>
                <span className="px-2 py-0.5 rounded text-xs font-mono font-medium bg-slate-800 text-cyan-300 border border-slate-700">
                  Gemini 2.5 Pro: {result.confidencePercentage}%
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                {result.primaryDiagnosis}
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-3xl leading-relaxed">
                {result.conditionSummary}
              </p>
            </div>
          </div>
          <button
            onClick={onNewScan}
            className="self-end sm:self-auto px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800/90 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors whitespace-nowrap"
          >
            Start New Scan
          </button>
        </div>
      </div>

      {/* EMERGENCY CASE SPECIAL MODULE: Hospital ER & Turn-by-Turn GPS + Medical Report */}
      {isEmergency && result.nearestHospitalER && (
        <div className="bg-slate-900 rounded-2xl border-2 border-rose-500/80 p-5 sm:p-6 shadow-2xl space-y-5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="inline-flex items-center gap-1.5 text-xs font-bold text-rose-400 uppercase tracking-wider">
                  <Hospital className="w-4 h-4" />
                  Nearest Emergency Department Detected
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                  Subscribed Hospital Partner Network
                </span>
              </div>

              <h3 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
                {result.nearestHospitalER.name}
                {result.nearestHospitalER.hasLevel1TraumaCenter && (
                  <span className="px-2 py-0.5 text-[11px] font-extrabold bg-red-950 text-red-300 border border-red-800 rounded">
                    Level 1 Trauma Center
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-300 flex items-center gap-1.5 mt-1">
                <MapPin className="w-3.5 h-3.5 text-rose-400" />
                {result.nearestHospitalER.address}
              </p>
            </div>

            {/* Quick Navigation & Call Actions */}
            <div className="flex flex-wrap items-center gap-2.5">
              <a
                href={`tel:${result.nearestHospitalER.emergencyPhone}`}
                className="flex items-center gap-1.5 px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-bold border border-slate-700 shadow-md transition-colors"
              >
                <Phone className="w-4 h-4 text-rose-400" />
                Call ER ({result.nearestHospitalER.emergencyPhone})
              </a>
              <button
                onClick={() => handleLaunchGoogleMaps(result.nearestHospitalER?.googleMapsUrl)}
                className="flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-rose-900/50 ring-2 ring-rose-400 transition-transform active:scale-95"
              >
                <Navigation className="w-4 h-4 animate-bounce" />
                <span>Launch Google Maps Turn-by-Turn</span>
                <ExternalLink className="w-3.5 h-3.5 opacity-80" />
              </button>
            </div>
          </div>

          {/* ER ETA & Drive Distance Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block mb-1">Estimated Drive Time</span>
              <div className="text-base sm:text-lg font-bold text-rose-400 flex items-center gap-1.5">
                <Clock className="w-4 h-4" />
                <span>{result.nearestHospitalER.estimatedDriveTimeMin} mins</span>
              </div>
            </div>
            <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block mb-1">Distance to ER</span>
              <div className="text-base sm:text-lg font-bold text-white flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-cyan-400" />
                <span>{result.nearestHospitalER.distanceKm} km</span>
              </div>
            </div>
            <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block mb-1">Bigtable Stream</span>
              <div className="text-base sm:text-lg font-bold text-cyan-400 font-mono">&lt; 4ms Ingest</div>
            </div>
            <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block mb-1">Surgical Team Status</span>
              <div className="text-base sm:text-lg font-bold text-amber-400">Pre-Notified</div>
            </div>
          </div>

          {/* Simultaneous Surgical Medical Report Highlight Box */}
          {result.surgicalMedicalReport && (
            <div className="bg-slate-950 rounded-xl p-4 sm:p-5 border border-rose-500/40 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 font-bold uppercase">
                    Code Red: Pre-Operative &amp; Emergency Surgery Scan
                  </span>
                  <h4 className="text-sm sm:text-base font-bold text-white mt-1">
                    Emergency Doctor &amp; Surgical Medical Report Synthesized
                  </h4>
                  <p className="text-xs text-slate-400">
                    Comprehensive digital scan and trauma protocol generated for arriving surgeons and ER physicians.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowReportModal(true)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
                  >
                    <Eye className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Preview Report</span>
                  </button>
                  <button
                    onClick={handleDownloadPDF}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-md transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download PDF Report</span>
                  </button>
                </div>
              </div>

              {/* Immediate Surgical Interventions Needed Checklist */}
              <div className="bg-rose-950/40 rounded-lg p-3 border border-rose-900/50">
                <span className="text-xs font-bold text-rose-300 block mb-2">
                  Immediate Interventions Ordered:
                </span>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-200">
                  {result.surgicalMedicalReport.immediateInterventionsNeeded.map((order, idx) => (
                    <li key={idx} className="flex items-start gap-2 bg-slate-900/80 p-2 rounded border border-rose-950">
                      <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                      <span>{order}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Medical Specialist Required Module */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl space-y-4">
        <div className="flex items-center gap-2.5 pb-3 border-b border-slate-800">
          <div className="w-9 h-9 rounded-xl bg-cyan-950 border border-cyan-800 flex items-center justify-center text-cyan-400">
            <Stethoscope className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">
              Recommended Medical Specialist Consultation
            </h3>
            <p className="text-xs text-slate-400">
              Targeted practitioner identified for accurate treatment of this condition
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800">
            <span className="text-xs font-semibold text-slate-400 block mb-1">
              Required Specialist
            </span>
            <div className="text-sm sm:text-base font-black text-cyan-300">
              {result.specialist.specialty}
            </div>
          </div>
          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 md:col-span-2">
            <span className="text-xs font-semibold text-slate-400 block mb-1">
              Clinical Rationale
            </span>
            <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
              {result.specialist.reason}
            </p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-slate-950/40 p-3.5 rounded-xl border border-slate-800/80 text-xs">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="text-slate-300">
              <strong className="text-slate-100">Consultation Urgency:</strong>{' '}
              {result.specialist.urgencyTimeframe}
            </span>
          </div>
          {result.specialist.preparationNotes && (
            <div className="text-slate-400">
              <strong>Patient Note:</strong> {result.specialist.preparationNotes}
            </div>
          )}
        </div>
      </div>

      {/* SCENARIO 1 ROUTINE CASE: Recommended Local Clinics */}
      {!isEmergency && result.routineClinics && result.routineClinics.length > 0 && (
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-emerald-950 border border-emerald-800 flex items-center justify-center text-emerald-400">
                <Hospital className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">
                  Best Local Clinics &amp; Hospitals for Treatment
                </h3>
                <p className="text-xs text-slate-400">
                  Recommended facilities tailored to your geographic location ({userLocation?.city || 'Local Region'})
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {result.routineClinics.map((clinic, idx) => (
              <div
                key={idx}
                className="bg-slate-950/80 rounded-xl p-4 border border-slate-800 hover:border-slate-700 transition-colors flex flex-col justify-between gap-3"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
                      {clinic.type}
                    </span>
                    <div className="flex items-center gap-1 text-xs font-bold text-amber-400">
                      <span>★ {clinic.rating}</span>
                    </div>
                  </div>
                  <h4 className="text-sm font-bold text-white mb-1">{clinic.name}</h4>
                  <p className="text-xs text-slate-400 flex items-center gap-1.5 mb-2">
                    <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                    <span>{clinic.address}</span>
                  </p>
                  <div className="flex flex-wrap gap-1 mb-2">
                    {clinic.specialtiesOffered.map((spec, sIdx) => (
                      <span
                        key={sIdx}
                        className="px-2 py-0.5 rounded text-[10px] bg-slate-900 text-slate-300 border border-slate-800"
                      >
                        {spec}
                      </span>
                    ))}
                  </div>
                  {clinic.bookingNote && (
                    <p className="text-[11px] text-emerald-400 font-medium">
                      ✓ {clinic.bookingNote}
                    </p>
                  )}
                </div>

                <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-900">
                  <div className="text-xs text-slate-400">
                    <span className="font-bold text-slate-200">{clinic.distanceKm} km</span> away
                  </div>
                  <div className="flex items-center gap-2">
                    <a
                      href={`tel:${clinic.phone}`}
                      className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
                      title="Call Clinic"
                    >
                      <Phone className="w-3.5 h-3.5" />
                    </a>
                    <button
                      onClick={() => handleLaunchGoogleMaps(clinic.googleMapsUrl)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition-colors"
                    >
                      <Navigation className="w-3.5 h-3.5" />
                      <span>Directions</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Optical Scan Findings & ABC Risk */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Visual Findings */}
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 shadow-xl">
          <h4 className="text-sm font-bold text-white flex items-center gap-2 mb-3">
            <Activity className="w-4 h-4 text-cyan-400" />
            <span>Video Stream Optical Findings</span>
          </h4>
          <ul className="space-y-2 text-xs text-slate-300">
            {result.visualFindings.map((finding, idx) => (
              <li key={idx} className="flex items-start gap-2 bg-slate-950/60 p-2.5 rounded-lg border border-slate-800/80">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 shrink-0" />
                <span>{finding}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Vital Signs / ABC Risk Assessment */}
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 shadow-xl">
          <h4 className="text-sm font-bold text-white flex items-center gap-2 mb-3">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Vitals &amp; Airway-Breathing-Circulation Triage</span>
          </h4>
          <div className="space-y-2 text-xs">
            <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/80">
              <span className="text-slate-400 font-medium block">ABC Status:</span>
              <span className="text-slate-200 font-semibold">{result.vitalSignsRiskAssessment.airwayBreathingCirculation}</span>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/80">
              <span className="text-slate-400 font-medium block">Consciousness / Neurological:</span>
              <span className="text-slate-200 font-semibold">{result.vitalSignsRiskAssessment.consciousnessLevel}</span>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/80">
              <span className="text-slate-400 font-medium block">Shock Risk Assessment:</span>
              <span className={`font-semibold ${isEmergency ? 'text-rose-400' : 'text-emerald-400'}`}>
                {result.vitalSignsRiskAssessment.shockRisk}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* First Aid & Immediate Actions */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl">
        <h4 className="text-sm font-bold text-white flex items-center gap-2 mb-3">
          <CheckCircle2 className="w-4 h-4 text-cyan-400" />
          <span>Immediate First Aid &amp; Action Plan</span>
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {result.firstAidAndImmediateActions.map((action, idx) => (
            <div
              key={idx}
              className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 text-xs text-slate-200"
            >
              <span className="w-5 h-5 rounded-full bg-slate-800 text-cyan-400 font-bold flex items-center justify-center shrink-0 text-[11px]">
                {idx + 1}
              </span>
              <span className="mt-0.5 leading-relaxed">{action}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Clinical Disclaimer */}
      <div className="text-[11px] text-slate-500 text-center max-w-2xl mx-auto py-2">
        {result.disclaimer}
      </div>

      {/* Medical Report Modal */}
      {showReportModal && result.surgicalMedicalReport && (
        <MedicalReportModal
          report={result.surgicalMedicalReport}
          hospital={result.nearestHospitalER}
          onClose={() => setShowReportModal(false)}
          onDownloadPDF={handleDownloadPDF}
        />
      )}
    </div>
  );
};
