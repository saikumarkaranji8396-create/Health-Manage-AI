import React, { useState, useEffect, useCallback } from 'react';
import { Header, AppActiveTab } from './components/Header';
import { CameraScanner } from './components/CameraScanner';
import { TriageResultView } from './components/TriageResultView';
import { HospitalSubscriptionsView } from './components/HospitalSubscriptionsView';
import { CloudDataConsole } from './components/CloudDataConsole';
import { OpenSourceStudio } from './components/OpenSourceStudio';
import { ScanAnalysisResult, UserLocation, SubscribedHospital } from './types';
import { Activity, ShieldAlert, Sparkles, AlertTriangle, Building2, Cloud, Globe } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<AppActiveTab>('scanner');
  const [userLocation, setUserLocation] = useState<UserLocation | null>(null);
  const [locationLoading, setLocationLoading] = useState<boolean>(false);
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisProgressStep, setAnalysisProgressStep] = useState<string>('');
  const [scanResult, setScanResult] = useState<ScanAnalysisResult | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [hospitals, setHospitals] = useState<SubscribedHospital[]>([]);

  // Fetch registered hospitals on mount
  useEffect(() => {
    fetchHospitals();
  }, []);

  const fetchHospitals = async () => {
    try {
      const res = await fetch('/api/subscriptions');
      const data = await res.json();
      if (data.success && data.hospitals) {
        setHospitals(data.hospitals);
      }
    } catch (err) {
      console.error('Failed to load subscriptions:', err);
    }
  };

  // Add new hospital subscription
  const handleAddHospital = async (payload: any): Promise<boolean> => {
    try {
      const res = await fetch('/api/subscriptions/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data.success && data.hospital) {
        setHospitals((prev) => [data.hospital, ...prev]);
        return true;
      }
      throw new Error(data.error || 'Failed to subscribe hospital');
    } catch (err: any) {
      setErrorMessage(err.message || 'Error subscribing hospital.');
      return false;
    }
  };

  // Geolocation detection
  const fetchUserLocation = useCallback(() => {
    setLocationLoading(true);
    if (!navigator.geolocation) {
      setUserLocation({
        latitude: 28.5355,
        longitude: 77.2910,
        city: 'New Delhi (Default)',
        country: 'India',
      });
      setLocationLoading(false);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        try {
          const res = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=10`,
            { headers: { 'User-Agent': 'AI-Healthcare-Agent-CloudData' } }
          );
          if (res.ok) {
            const data = await res.json();
            const city =
              data.address?.city ||
              data.address?.town ||
              data.address?.county ||
              data.address?.state ||
              'Current Location';
            const country = data.address?.country || 'Local';
            setUserLocation({ latitude: lat, longitude: lng, city, country });
          } else {
            setUserLocation({ latitude: lat, longitude: lng, city: 'Current Location' });
          }
        } catch {
          setUserLocation({ latitude: lat, longitude: lng, city: 'Current Location' });
        } finally {
          setLocationLoading(false);
        }
      },
      (err) => {
        console.warn('Geolocation denied or timed out:', err);
        setUserLocation({
          latitude: 37.7749,
          longitude: -122.4194,
          city: 'San Francisco (Default)',
          country: 'United States',
        });
        setLocationLoading(false);
      },
      { timeout: 8000, enableHighAccuracy: true }
    );
  }, []);

  useEffect(() => {
    fetchUserLocation();
  }, [fetchUserLocation]);

  // Handle Scan & Analysis
  const handleCaptureScan = async (
    imageBase64: string,
    notes: string,
    scenarioHint?: string
  ) => {
    setIsAnalyzing(true);
    setErrorMessage(null);

    setAnalysisProgressStep('Extracting optical video scan frames & sensor telemetry...');
    const t1 = setTimeout(() => {
      setAnalysisProgressStep('Running Gemini 2.5 Pro Multimodal Neural Pathology Diagnosis...');
    }, 600);
    const t2 = setTimeout(() => {
      setAnalysisProgressStep('Streaming vitals to Cloud Bigtable & querying BigQuery Geospatial ER Catchment...');
    }, 1300);

    try {
      const response = await fetch('/api/scan/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64,
          userNotes: notes,
          scenarioHint,
          location: userLocation || {
            latitude: 37.7749,
            longitude: -122.4194,
            city: 'Metro Area',
          },
        }),
      });
      clearTimeout(t1);
      clearTimeout(t2);

      const resData = await response.json();
      if (resData.success && resData.data) {
        setScanResult(resData.data);
      } else {
        throw new Error(resData.error || 'Unable to complete scan analysis.');
      }
    } catch (err: any) {
      console.error('Scan failed:', err);
      setErrorMessage(
        err.message || 'Error communicating with healthcare triage agent. Please try again.'
      );
    } finally {
      setIsAnalyzing(false);
      setAnalysisProgressStep('');
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-black">
      {/* App Header */}
      <Header
        location={userLocation}
        locationLoading={locationLoading}
        onRequestLocation={fetchUserLocation}
        isCameraActive={isCameraActive}
        activeTab={activeTab}
        onTabChange={(tab) => {
          setActiveTab(tab);
          if (tab === 'scanner') setScanResult(null);
        }}
        subscribedHospitalCount={hospitals.length}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* Error Alert */}
        {errorMessage && (
          <div className="bg-rose-950/80 border border-rose-700 p-4 rounded-xl text-rose-200 text-xs flex items-center justify-between gap-3 shadow-lg">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button
              onClick={() => setErrorMessage(null)}
              className="text-slate-400 hover:text-white text-xs underline"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* ================================================================ */}
        {/* TAB 1: BODY SCANNER & TRIAGE */}
        {/* ================================================================ */}
        {activeTab === 'scanner' && (
          <div className="space-y-6">
            {/* System Guidance Banner */}
            <div className="bg-slate-900/70 border border-slate-800 rounded-xl px-4 py-3 text-xs text-slate-300 flex flex-wrap items-center justify-between gap-3 shadow-md">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>
                  <strong className="text-white">Continuous AI Clinical Triage:</strong> Evaluates live camera video to triage into{' '}
                  <span className="text-emerald-400 font-semibold">Scenario 1 (Normal Routine)</span> or{' '}
                  <span className="text-rose-400 font-semibold">Scenario 2 (Life-Threatening Emergency)</span>.
                </span>
              </div>
              <div className="flex items-center gap-2 text-[11px] text-slate-400">
                <span className="inline-block w-2 h-2 rounded-full bg-emerald-400" />
                <span>Cloud Bigtable Telemetry Active</span>
              </div>
            </div>

            {scanResult ? (
              <TriageResultView
                result={scanResult}
                userLocation={userLocation}
                onNewScan={() => setScanResult(null)}
                onNavigateToSubscriptions={() => setActiveTab('subscriptions')}
              />
            ) : (
              <div className="space-y-6">
                {/* Analysis Loading Screen */}
                {isAnalyzing && (
                  <div className="bg-slate-900 border-2 border-cyan-500/60 rounded-2xl p-8 text-center space-y-4 shadow-2xl animate-pulse">
                    <div className="relative w-16 h-16 mx-auto">
                      <div className="w-16 h-16 rounded-full border-4 border-cyan-500/20 border-t-cyan-400 animate-spin" />
                      <Activity className="w-7 h-7 text-cyan-400 absolute inset-0 m-auto animate-ping" />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-white tracking-tight">
                        AI Healthcare Agent Analyzing Video Stream
                      </h3>
                      <p className="text-xs text-cyan-300 font-mono mt-1">
                        {analysisProgressStep || 'Performing rapid triage and pathology detection...'}
                      </p>
                    </div>
                  </div>
                )}

                {/* Camera Scanner View */}
                <CameraScanner
                  onCaptureScan={handleCaptureScan}
                  isAnalyzing={isAnalyzing}
                  onCameraStateChange={setIsCameraActive}
                  onNavigateToSubscriptions={() => setActiveTab('subscriptions')}
                />

                {/* Scenario Architecture Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Scenario 1 Card */}
                  <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                      <h3 className="text-sm font-bold text-emerald-400 uppercase tracking-wider">
                        Scenario 1: Normal Case (Routine Diagnosis)
                      </h3>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      AI analyzes video to diagnose non-urgent conditions (contact dermatitis, mild conjunctivitis, ligament sprains). It specifies the exact specialist (e.g. Dermatologist, Orthopedist) and recommends top local clinics near your GPS location.
                    </p>
                  </div>

                  {/* Scenario 2 Card */}
                  <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
                      <h3 className="text-sm font-bold text-rose-400 uppercase tracking-wider">
                        Scenario 2: Emergency Case (Life-Threatening)
                      </h3>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Detects arterial bleeding, stroke facial droop, or critical trauma. Instantly locates nearest ER hospital, launches Google Maps Turn-by-Turn GPS navigation, and generates a surgical medical report (PDF &amp; digital scan) for arriving surgeons.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================================================================ */}
        {/* TAB 2: HOSPITAL SUBSCRIPTIONS ($104 India / $1,000 Global) */}
        {/* ================================================================ */}
        {activeTab === 'subscriptions' && (
          <HospitalSubscriptionsView
            hospitals={hospitals}
            onAddHospital={handleAddHospital}
          />
        )}

        {/* ================================================================ */}
        {/* TAB 3: CLOUD DATA ARCHITECTURE CONSOLE */}
        {/* ================================================================ */}
        {activeTab === 'cloud_architecture' && <CloudDataConsole />}

        {/* ================================================================ */}
        {/* TAB 4: OPEN SOURCE & GEMINI 2.5 PRO CODE STUDIO */}
        {/* ================================================================ */}
        {activeTab === 'open_source_studio' && <OpenSourceStudio />}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 px-6 text-center text-xs text-slate-500 flex flex-wrap items-center justify-between gap-3 max-w-7xl mx-auto w-full">
        <p>
          AI Healthcare Agent &amp; Cloud Data Platform • Built with Gemini 2.5 Pro Vision &amp; Code Generation
        </p>
        <div className="flex items-center gap-3 font-mono text-[11px] text-slate-400">
          <span>Bigtable NoSQL</span>
          <span>•</span>
          <span>Spanner ACID</span>
          <span>•</span>
          <span>BigQuery Geo</span>
          <span>•</span>
          <span>GCS Colossus</span>
          <span>•</span>
          <span>Cloud NAT</span>
        </div>
      </footer>
    </div>
  );
}
