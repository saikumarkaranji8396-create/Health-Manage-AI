import { jsPDF } from 'jspdf';
import { SurgicalMedicalReport, HospitalER } from '../types';

export function generateMedicalReportPDF(
  report: SurgicalMedicalReport,
  hospital?: HospitalER,
  patientName = 'Patient Scan (Anonymous / Rapid Triage)'
) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 14;

  // Header Banner
  const isEmergency = report.patientAcuityCode.includes('RED') || report.patientAcuityCode.includes('ORANGE');
  doc.setFillColor(isEmergency ? 185 : 40, isEmergency ? 28 : 116, isEmergency ? 28 : 166);
  doc.rect(0, 0, pageWidth, 24, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('AI HEALTHCARE AGENT - EMERGENCY MEDICAL & SURGICAL REPORT', 14, 11);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('RAPID VIDEO SCAN CLINICAL TRIAGE - FOR PHYSICIAN / SURGEON REVIEW', 14, 18);

  y = 32;

  // Metadata Box
  doc.setFillColor(245, 247, 250);
  doc.setDrawColor(218, 222, 229);
  doc.roundedRect(14, y, pageWidth - 28, 26, 3, 3, 'FD');

  doc.setTextColor(30, 41, 59);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text('REPORT ID:', 18, y + 7);
  doc.setFont('helvetica', 'normal');
  doc.text(report.reportId, 42, y + 7);

  doc.setFont('helvetica', 'bold');
  doc.text('TIMESTAMP:', 110, y + 7);
  doc.setFont('helvetica', 'normal');
  doc.text(new Date(report.timestamp).toLocaleString(), 138, y + 7);

  doc.setFont('helvetica', 'bold');
  doc.text('PATIENT IDENTIFIER:', 18, y + 14);
  doc.setFont('helvetica', 'normal');
  doc.text(patientName, 58, y + 14);

  doc.setFont('helvetica', 'bold');
  doc.text('ACUITY CODE:', 110, y + 14);
  doc.setTextColor(isEmergency ? 185 : 34, isEmergency ? 28 : 197, isEmergency ? 28 : 94);
  doc.setFont('helvetica', 'bold');
  doc.text(report.patientAcuityCode, 138, y + 14);

  doc.setTextColor(30, 41, 59);
  doc.setFont('helvetica', 'bold');
  doc.text('DESTINATION ER:', 18, y + 21);
  doc.setFont('helvetica', 'normal');
  doc.text(hospital?.name || report.facilityDestination || 'Nearest Trauma Center', 52, y + 21);

  y += 34;

  // Section 1: Chief Complaint & Suspected Pathology
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text('1. CHIEF COMPLAINT & SUSPECTED PATHOLOGY', 14, y);
  y += 4;
  doc.setDrawColor(203, 213, 225);
  doc.line(14, y, pageWidth - 14, y);
  y += 6;

  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text('Chief Complaint:', 14, y);
  doc.setFont('helvetica', 'normal');
  doc.text(report.chiefComplaint, 46, y);
  y += 6;

  doc.setFont('helvetica', 'bold');
  doc.text('Suspected Pathology:', 14, y);
  doc.setFont('helvetica', 'normal');
  const splitPathology = doc.splitTextToSize(report.suspectedPathology, pageWidth - 60);
  doc.text(splitPathology, 54, y);
  y += splitPathology.length * 5 + 3;

  // Section 2: Clinical Observations
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('2. REAL-TIME OPTICAL SCAN FINDINGS', 14, y);
  y += 4;
  doc.line(14, y, pageWidth - 14, y);
  y += 6;

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  report.clinicalObservations.forEach((obs) => {
    doc.text(`• ${obs}`, 16, y);
    y += 5;
  });
  y += 2;

  // Section 3: Vital Signs & ABC Risk Assessment
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('3. AIRWAY, BREATHING, CIRCULATION (ABC) & SHOCK RISK', 14, y);
  y += 4;
  doc.line(14, y, pageWidth - 14, y);
  y += 6;

  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text('ABC Status:', 14, y);
  doc.setFont('helvetica', 'normal');
  doc.text(report.vitalSignsRiskAssessment.airwayBreathingCirculation, 42, y);
  y += 5;

  doc.setFont('helvetica', 'bold');
  doc.text('Consciousness:', 14, y);
  doc.setFont('helvetica', 'normal');
  doc.text(report.vitalSignsRiskAssessment.consciousnessLevel, 42, y);
  y += 5;

  doc.setFont('helvetica', 'bold');
  doc.text('Shock Severity Risk:', 14, y);
  doc.setFont('helvetica', 'normal');
  doc.text(report.vitalSignsRiskAssessment.shockRisk, 52, y);
  y += 5;

  if (report.vitalSignsRiskAssessment.estimatedBloodLoss) {
    doc.setFont('helvetica', 'bold');
    doc.text('Est. Blood Loss:', 14, y);
    doc.setFont('helvetica', 'normal');
    doc.text(report.vitalSignsRiskAssessment.estimatedBloodLoss, 44, y);
    y += 5;
  }
  y += 3;

  // Section 4: Immediate Interventions
  doc.setFillColor(254, 242, 242);
  doc.roundedRect(14, y, pageWidth - 28, 44, 2, 2, 'FD');
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(185, 28, 28);
  doc.text('4. IMMEDIATE SURGICAL / MEDICAL INTERVENTIONS (STAT)', 18, y + 7);
  y += 12;

  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 41, 59);
  report.immediateInterventionsNeeded.slice(0, 4).forEach((item) => {
    doc.text(`[!] ${item}`, 18, y);
    y += 5;
  });

  if (report.anesthesiaSurgicalPrecautions && report.anesthesiaSurgicalPrecautions.length > 0) {
    y += 2;
    doc.setFont('helvetica', 'italic');
    doc.text(`Anesthesia Note: ${report.anesthesiaSurgicalPrecautions[0]}`, 18, y);
    y += 5;
  }
  y += 12;

  // Section 5: Pre-Hospital Protocol
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text('5. PRE-HOSPITAL & PARAMEDIC STABILIZATION PROTOCOL', 14, y);
  y += 4;
  doc.line(14, y, pageWidth - 14, y);
  y += 6;

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  report.preHospitalOrders.forEach((order) => {
    doc.text(`• ${order}`, 16, y);
    y += 5;
  });

  // Footer / Attending signature
  y = Math.max(y + 8, 260);
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('Report synthesized via AI Healthcare Agent Clinical Triage Subsystem.', 14, y);
  doc.text('Persisted to GCS Colossus Vault & Synced to Cloud Spanner Transaction DB.', 14, y + 4);
  doc.setDrawColor(148, 163, 184);
  doc.line(pageWidth - 75, y + 3, pageWidth - 14, y + 3);
  doc.text('Attending Physician / Surgeon Signature', pageWidth - 72, y + 8);

  // Trigger Download
  doc.save(`Medical_Report_${report.reportId}.pdf`);
}
